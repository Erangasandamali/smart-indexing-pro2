<?php
if (!defined('ABSPATH')) {
    exit;
}

class SIP_REST_API {
    
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }
    
    public function register_routes() {
        register_rest_route('sip/v1', '/submit-url', array(
            'methods' => 'POST',
            'callback' => array($this, 'submit_url'),
            'permission_callback' => array($this, 'check_permissions'),
            'args' => array(
                'url' => array(
                    'required' => true,
                    'validate_callback' => function($param, $request, $key) {
                        return filter_var($param, FILTER_VALIDATE_URL);
                    }
                ),
                'api_key' => array(
                    'required' => true,
                    'validate_callback' => function($param, $request, $key) {
                        return !empty($param);
                    }
                )
            )
        ));
        
        register_rest_route('sip/v1', '/queue-status', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_queue_status'),
            'permission_callback' => array($this, 'check_permissions')
        ));
        
        register_rest_route('sip/v1', '/indexing-status/(?P<url>[^/]+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_indexing_status'),
            'permission_callback' => array($this, 'check_permissions')
        ));
    }
    
    public function check_permissions($request) {
        $api_key = $request->get_header('X-API-Key') ?: $request->get_param('api_key');
        $stored_key = get_option('sip_rest_api_key', wp_generate_password(32, false));
        
        if (!$stored_key) {
            update_option('sip_rest_api_key', wp_generate_password(32, false));
        }
        
        return hash_equals($stored_key, $api_key);
    }
    
    public function submit_url($request) {
        $url = $request->get_param('url');
        
        if (!class_exists('SIP_Queue_Manager')) {
            return new WP_Error('plugin_error', 'Queue manager not available', array('status' => 500));
        }
        
        $queue_manager = new SIP_Queue_Manager();
        $result = $queue_manager->add_url_to_queue($url);
        
        if ($result['success']) {
            return new WP_REST_Response(array(
                'success' => true,
                'message' => $result['message'],
                'url' => $url
            ), 200);
        } else {
            return new WP_Error('submission_failed', $result['message'], array('status' => 400));
        }
    }
    
    public function get_queue_status($request) {
        if (!class_exists('SIP_Queue_Manager')) {
            return new WP_Error('plugin_error', 'Queue manager not available', array('status' => 500));
        }
        
        $queue_manager = new SIP_Queue_Manager();
        $stats = $queue_manager->get_queue_stats();
        
        return new WP_REST_Response($stats, 200);
    }
    
    public function get_indexing_status($request) {
        $url = urldecode($request->get_param('url'));
        
        global $wpdb;
        $status = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}sip_indexing_status WHERE url = %s",
            $url
        ));
        
        if ($status) {
            return new WP_REST_Response($status, 200);
        } else {
            return new WP_Error('not_found', 'URL not found in indexing status', array('status' => 404));
        }
    }
}