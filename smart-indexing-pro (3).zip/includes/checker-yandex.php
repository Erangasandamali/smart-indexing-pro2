<?php
if (!defined('ABSPATH')) {
    exit;
}

class SIP_Yandex_Checker {
    
    private $indexing_table;
    
    public function __construct() {
        global $wpdb;
        $this->indexing_table = $wpdb->prefix . 'sip_indexing_status';
    }
    
    public function submit_url($url, $api_key) {
        // Yandex Webmaster API implementation
        $response = wp_remote_post('https://api.webmaster.yandex.net/v4/user/{user_id}/hosts/{host_id}/recrawl/queue/', array(
            'headers' => array(
                'Authorization' => 'OAuth ' . $api_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'url' => $url
            )),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return array('success' => false, 'message' => $response->get_error_message());
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        
        if ($status_code === 200) {
            $this->update_indexing_status($url, 'unknown', 'yandex');
            return array('success' => true, 'message' => 'URL submitted to Yandex successfully');
        } else {
            return array('success' => false, 'message' => 'Yandex API Error: ' . wp_remote_retrieve_body($response));
        }
    }
    
    public function check_indexing_status($url) {
        // Simple check using site: operator on Yandex
        $search_url = 'https://yandex.com/search/?text=site:' . urlencode($url);
        
        $response = wp_remote_get($search_url, array(
            'timeout' => 30,
            'user-agent' => 'Mozilla/5.0 (compatible; WordPress Smart Indexing Pro)'
        ));
        
        if (is_wp_error($response)) {
            return array('status' => 'error', 'message' => $response->get_error_message());
        }
        
        $body = wp_remote_retrieve_body($response);
        
        // Check if URL appears in results
        if (strpos($body, 'нашлось') === false && strpos($body, 'found') === false) {
            $status = 'not_indexed';
        } elseif (strpos($body, $url) !== false) {
            $status = 'indexed';
        } else {
            $status = 'unknown';
        }
        
        // Update status in database
        $this->update_indexing_status($url, $status, 'yandex');
        
        return array('status' => $status, 'message' => 'Yandex status checked successfully');
    }
    
    private function update_indexing_status($url, $status, $engine) {
        global $wpdb;
        
        $post_id = url_to_postid($url);
        
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->indexing_table} WHERE url = %s",
            $url
        ));
        
        if ($existing) {
            $update_data = array(
                'last_checked' => current_time('mysql'),
                'updated_at' => current_time('mysql')
            );
            
            if ($engine === 'yandex') {
                $update_data['yandex_status'] = $status;
            }
            
            $wpdb->update(
                $this->indexing_table,
                $update_data,
                array('url' => $url)
            );
        } else {
            $insert_data = array(
                'post_id' => $post_id,
                'url' => $url,
                'last_checked' => current_time('mysql'),
                'created_at' => current_time('mysql')
            );
            
            if ($engine === 'yandex') {
                $insert_data['yandex_status'] = $status;
            }
            
            $wpdb->insert($this->indexing_table, $insert_data);
        }
    }
}