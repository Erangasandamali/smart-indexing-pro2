jQuery(document).ready(function($) {
    console.log('Smart Indexing Pro Admin JS loaded');
    
    var jsonContent = '';
    
    // File upload handling for API keys
    $(document).on('click', '#choose-file-btn', function() {
        $('#json-file').click();
    });
    
    $('#json-file').on('change', function() {
        var file = this.files[0];
        if (file) {
            $('#file-name').text(file.name);
            
            var reader = new FileReader();
            reader.onload = function(e) {
                jsonContent = e.target.result;
                console.log('JSON file loaded, length:', jsonContent.length);
            };
            reader.readAsText(file);
        } else {
            $('#file-name').text('No file chosen');
            jsonContent = '';
        }
    });
    
    // Upload API Key form submission
    $('#upload-api-key-form').on('submit', function(e) {
        e.preventDefault();
        console.log('Upload API key form submitted');
        
        var keyName = $('#key-name').val().trim();
        
        if (!keyName) {
            alert('Please provide a key name');
            return;
        }
        
        if (!jsonContent) {
            alert('Please select a JSON file');
            return;
        }
        
        var $submitBtn = $('#upload-api-key');
        $submitBtn.prop('disabled', true).html('<span class="dashicons dashicons-update"></span> Uploading...');
        
        $.ajax({
            url: ajaxurl || sip_ajax.ajax_url,
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'sip_upload_api_key',
                nonce: sip_ajax.nonce,
                key_name: keyName,
                json_content: jsonContent
            },
            success: function(response) {
                console.log('Upload API key response:', response);
                if (response && response.success) {
                    alert('API Key uploaded successfully!');
                    $('#key-name').val('');
                    $('#file-name').text('No file chosen');
                    $('#json-file').val('');
                    jsonContent = '';
                    location.reload();
                } else {
                    var message = response && response.data && response.data.message ? response.data.message : 'Upload failed';
                    alert('Error: ' + message);
                }
            },
            error: function(xhr, status, error) {
                console.log('Upload API key error:', xhr.responseText);
                alert('Upload failed: ' + error);
            },
            complete: function() {
                $submitBtn.prop('disabled', false).html('<span class="dashicons dashicons-upload"></span> Upload API Key');
            }
        });
    });
    
    // Upload API Key button click
    $(document).on('click', '#upload-api-key', function(e) {
        e.preventDefault();
        console.log('Upload API Key button clicked');
        $('#upload-api-key-form').submit();
    });
    
    // Submit URL for indexing
    $(document).on('click', '#submit-manual-url', function(e) {
        e.preventDefault();
        console.log('Submit URL clicked');
        
        var url = $('#manual-url').val().trim();
        if (!url) {
            alert('Please enter a URL');
            return;
        }
        
        var $button = $(this);
        var originalText = $button.html();
        $button.prop('disabled', true).html('<span class="dashicons dashicons-update spin"></span> Submitting...');
        
        $.ajax({
            url: ajaxurl || sip_ajax.ajax_url,
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'sip_submit_url',
                nonce: sip_ajax.nonce,
                url: url
            },
            success: function(response) {
                console.log('Submit URL response:', response);
                if (response && response.success) {
                    alert('URL submitted successfully!');
                    $('#manual-url').val('');
                    // Refresh the page to show updated queue
                    setTimeout(function() {
                        location.reload();
                    }, 1000);
                } else {
                    var message = response && response.data && response.data.message ? response.data.message : 'Submission failed';
                    alert('Error: ' + message);
                }
            },
            error: function(xhr, status, error) {
                console.log('Submit URL Error:', xhr.responseText);
                alert('Submission failed: ' + error);
            },
            complete: function() {
                $button.prop('disabled', false).html(originalText);
            }
        });
    });
    
    // Delete API Key
    $(document).on('click', '.delete-api-key, .delete-key', function(e) {
        e.preventDefault();
        console.log('Delete API key clicked');
        
        if (!confirm('Are you sure you want to delete this API key?')) {
            return;
        }
        
        var keyId = $(this).data('key-id');
        var $row = $(this).closest('tr');
        var $button = $(this);
        var originalText = $button.html();
        
        if (!keyId) {
            alert('Invalid key ID');
            return;
        }
        
        $button.prop('disabled', true).html('<span class="dashicons dashicons-update spin"></span> Deleting...');
        
        $.ajax({
            url: ajaxurl || sip_ajax.ajax_url,
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'sip_delete_api_key',
                nonce: sip_ajax.nonce,
                key_id: keyId
            },
            success: function(response) {
                console.log('Delete API key response:', response);
                if (response && response.success) {
                    $row.fadeOut(function() {
                        $(this).remove();
                    });
                    alert('API Key deleted successfully!');
                } else {
                    var message = response && response.data && response.data.message ? response.data.message : 'Delete failed';
                    alert('Error: ' + message);
                }
            },
            error: function(xhr, status, error) {
                console.log('Delete API key error:', xhr.responseText);
                alert('Delete failed: ' + error);
            },
            complete: function() {
                $button.prop('disabled', false).html(originalText);
            }
        });
    });
    
    // Reindex URL
    $(document).on('click', '.reindex-url, .recheck-url', function(e) {
        e.preventDefault();
        console.log('Reindex URL clicked');
        
        var url = $(this).data('url');
        var $button = $(this);
        var originalText = $button.html();
        
        if (!url) {
            alert('Invalid URL');
            return;
        }
        
        $button.prop('disabled', true).html('<span class="dashicons dashicons-update spin"></span> Processing...');
        
        $.ajax({
            url: ajaxurl || sip_ajax.ajax_url,
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'sip_reindex_url',
                nonce: sip_ajax.nonce,
                url: url
            },
            success: function(response) {
                console.log('Reindex response:', response);
                if (response && response.success) {
                    alert('URL queued for reindexing!');
                    setTimeout(function() {
                        location.reload();
                    }, 1000);
                } else {
                    var message = response && response.data && response.data.message ? response.data.message : 'Reindex failed';
                    alert('Error: ' + message);
                }
            },
            error: function(xhr, status, error) {
                console.log('Reindex Error:', xhr.responseText);
                alert('Reindex failed: ' + error);
            },
            complete: function() {
                $button.prop('disabled', false).html(originalText);
            }
        });
    });
    
    // Remove URL from queue
    $(document).on('click', '.remove-url', function(e) {
        e.preventDefault();
        console.log('Remove URL clicked');
        
        if (!confirm('Are you sure you want to remove this URL from the queue?')) {
            return;
        }
        
        var url = $(this).data('url');
        var $row = $(this).closest('tr');
        var $button = $(this);
        var originalText = $button.html();
        
        if (!url) {
            alert('Invalid URL');
            return;
        }
        
        $button.prop('disabled', true).html('<span class="dashicons dashicons-update spin"></span> Removing...');
        
        $.ajax({
            url: ajaxurl || sip_ajax.ajax_url,
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'sip_remove_url',
                nonce: sip_ajax.nonce,
                url: url
            },
            success: function(response) {
                console.log('Remove URL response:', response);
                if (response && response.success) {
                    $row.fadeOut(function() {
                        $(this).remove();
                    });
                    alert('URL removed from queue!');
                } else {
                    var message = response && response.data && response.data.message ? response.data.message : 'Remove failed';
                    alert('Error: ' + message);
                }
            },
            error: function(xhr, status, error) {
                console.log('Remove URL Error:', xhr.responseText);
                alert('Remove failed: ' + error);
            },
            complete: function() {
                $button.prop('disabled', false).html(originalText);
            }
        });
    });
    
    // Queue filter functionality
    $('#queue-filter-form').on('submit', function(e) {
        e.preventDefault();
        var formData = $(this).serialize();
        window.location.href = window.location.pathname + '?' + formData;
    });
    
    // Auto-refresh dashboard stats every 30 seconds
    if ($('.sip-dashboard').length > 0) {
        setInterval(function() {
            refreshDashboardStats();
        }, 30000);
    }
    
    function refreshDashboardStats() {
        $.ajax({
            url: ajaxurl || sip_ajax.ajax_url,
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'sip_get_dashboard_stats',
                nonce: sip_ajax.nonce
            },
            success: function(response) {
                if (response && response.success) {
                    console.log('Stats refreshed');
                }
            },
            error: function(xhr, status, error) {
                console.log('Stats refresh error:', error);
            }
        });
    }
    
    // Debug: Log all clicks
    $(document).on('click', 'button, .sip-btn', function() {
        console.log('Button clicked:', $(this).attr('id') || $(this).attr('class'), $(this).text());
    });
    
    // Add CSS for spinning animation
    if (!$('#sip-spin-css').length) {
        $('head').append('<style id="sip-spin-css">.spin { animation: spin 1s linear infinite; } @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }</style>');
    }
});