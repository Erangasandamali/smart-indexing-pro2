<?php
if (!defined('ABSPATH')) {
    exit;
}

class SIP_Notification_Manager {
    
    public function __construct() {
        add_action('sip_quota_exceeded', array($this, 'send_quota_alert'));
        add_action('sip_submission_failed', array($this, 'send_failure_alert'));
        add_action('sip_daily_report', array($this, 'send_daily_report'));
    }
    
    public function send_quota_alert($api_key_name) {
        $settings = get_option('sip_settings', array());
        
        $message = "⚠️ Smart Indexing Pro Alert\n\n";
        $message .= "API Key '{$api_key_name}' has exceeded its daily quota.\n";
        $message .= "Site: " . get_site_url() . "\n";
        $message .= "Time: " . current_time('Y-m-d H:i:s');
        
        $this->send_notifications($message, 'quota_exceeded');
    }
    
    public function send_failure_alert($url, $error_message) {
        $settings = get_option('sip_settings', array());
        
        $message = "❌ Smart Indexing Pro Failure\n\n";
        $message .= "Failed to submit URL: {$url}\n";
        $message .= "Error: {$error_message}\n";
        $message .= "Site: " . get_site_url() . "\n";
        $message .= "Time: " . current_time('Y-m-d H:i:s');
        
        $this->send_notifications($message, 'submission_failed');
    }
    
    public function send_daily_report() {
        $settings = get_option('sip_settings', array());
        
        if (!isset($settings['daily_reports']) || !$settings['daily_reports']) {
            return;
        }
        
        $queue_manager = new SIP_Queue_Manager();
        $api_manager = new SIP_API_Manager();
        $logger = new SIP_Logger();
        
        $queue_stats = $queue_manager->get_queue_stats();
        $log_stats = $logger->get_log_stats();
        
        $message = "📊 Smart Indexing Pro Daily Report\n\n";
        $message .= "Site: " . get_site_url() . "\n";
        $message .= "Date: " . current_time('Y-m-d') . "\n\n";
        $message .= "Queue Status:\n";
        $message .= "- Pending: {$queue_stats['pending']}\n";
        $message .= "- Completed: {$queue_stats['completed']}\n";
        $message .= "- Failed: {$queue_stats['failed']}\n\n";
        $message .= "API Usage:\n";
        $message .= "- Total Usage Today: " . $api_manager->get_total_usage_today() . "\n";
        $message .= "- Active Keys: " . $api_manager->get_active_keys_count() . "\n\n";
        $message .= "Submissions:\n";
        $message .= "- Successful: {$log_stats['successful_submissions']}\n";
        $message .= "- Failed: {$log_stats['failed_submissions']}\n";
        
        $this->send_notifications($message, 'daily_report');
    }
    
    private function send_notifications($message, $type) {
        $settings = get_option('sip_settings', array());
        
        // Email notifications
        if (isset($settings['email_notifications']) && $settings['email_notifications']) {
            $this->send_email_notification($message, $type);
        }
        
        // Slack notifications
        if (isset($settings['slack_webhook']) && !empty($settings['slack_webhook'])) {
            $this->send_slack_notification($message);
        }
        
        // Telegram notifications
        if (isset($settings['telegram_bot_token']) && isset($settings['telegram_chat_id']) && 
            !empty($settings['telegram_bot_token']) && !empty($settings['telegram_chat_id'])) {
            $this->send_telegram_notification($message);
        }
    }
    
    private function send_email_notification($message, $type) {
        $settings = get_option('sip_settings', array());
        $email = isset($settings['notification_email']) ? $settings['notification_email'] : get_option('admin_email');
        
        $subject_map = array(
            'quota_exceeded' => 'Smart Indexing Pro - API Quota Exceeded',
            'submission_failed' => 'Smart Indexing Pro - URL Submission Failed',
            'daily_report' => 'Smart Indexing Pro - Daily Report'
        );
        
        $subject = isset($subject_map[$type]) ? $subject_map[$type] : 'Smart Indexing Pro Notification';
        
        wp_mail($email, $subject, $message);
    }
    
    private function send_slack_notification($message) {
        $settings = get_option('sip_settings', array());
        $webhook_url = $settings['slack_webhook'];
        
        $payload = json_encode(array(
            'text' => $message,
            'username' => 'Smart Indexing Pro',
            'icon_emoji' => ':robot_face:'
        ));
        
        wp_remote_post($webhook_url, array(
            'body' => $payload,
            'headers' => array(
                'Content-Type' => 'application/json'
            )
        ));
    }
    
    private function send_telegram_notification($message) {
        $settings = get_option('sip_settings', array());
        $bot_token = $settings['telegram_bot_token'];
        $chat_id = $settings['telegram_chat_id'];
        
        $url = "https://api.telegram.org/bot{$bot_token}/sendMessage";
        
        wp_remote_post($url, array(
            'body' => array(
                'chat_id' => $chat_id,
                'text' => $message,
                'parse_mode' => 'HTML'
            )
        ));
    }
}