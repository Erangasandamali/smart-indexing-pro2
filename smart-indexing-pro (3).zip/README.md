
# Smart Indexing Pro WordPress Plugin

A comprehensive WordPress plugin for automated search engine indexing management across Google, Bing, and Yandex.

## Features

### 🔄 API Key Rotation
- Support for up to 20 Google Indexing API service accounts
- Automatic rotation when quotas are reached
- Daily quota reset and tracking
- Real-time usage monitoring

### 🎯 Multi-Engine Support
- **Google Search**: Indexing API with service account rotation
- **Bing Search**: Webmaster Tools API integration
- **Yandex Search**: Webmaster Tools API support

### 🤖 Intelligent Automation
- Auto-submit new published posts/pages
- Auto-submit updated content
- Retry unindexed URLs with configurable frequency
- Queue management with priority handling

### 📊 Comprehensive Dashboard
- Real-time indexing status for all posts
- Visual status indicators (✅ Indexed, ❌ Not Indexed, ⏳ Pending)
- Bulk operations and manual submissions
- Service-specific statistics and reporting

### 🔧 Advanced Management
- Upload and test API keys with validation
- Configurable retry attempts and frequencies
- Email notifications and daily reports
- Detailed logging and activity tracking

## Installation

1. Upload the `smart-indexing-pro` folder to your `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to 'Smart Indexing' in your admin menu to configure

## Configuration

### Google Indexing API Setup
1. Create a Google Cloud Project
2. Enable the Indexing API
3. Create a Service Account and download the JSON key
4. Upload the JSON key through the plugin interface

### Bing Webmaster Tools Setup
1. Register your site with Bing Webmaster Tools
2. Generate an API key
3. Upload the API key through the plugin interface

### Yandex Webmaster Setup
1. Register your site with Yandex.Webmaster
2. Create an OAuth application and get a token
3. Upload the OAuth token through the plugin interface

## Usage

### Automatic Operation
Once configured, the plugin automatically:
- Submits new posts to configured search engines
- Retries unindexed content based on your settings
- Rotates through available API keys
- Monitors indexing status

### Manual Operations
- **Dashboard**: View status of all posts/pages
- **Bulk Submit**: Select multiple posts for manual submission
- **Individual Actions**: Recheck status or force submission per post
- **API Management**: Test, activate, or deactivate API keys

## File Structure

```
smart-indexing-pro/
├── includes/
│   ├── api-manager.php      # API key rotation and management
│   ├── queue-manager.php    # URL queue and scheduling
│   ├── checker-google.php   # Google indexing status checking
│   ├── checker-bing.php     # Bing indexing status checking
│   ├── checker-yandex.php   # Yandex indexing status checking
│   └── logger.php           # Logging and reporting
├── admin/
│   ├── dashboard.php        # Main dashboard interface
│   ├── settings.php         # Plugin configuration
│   └── api-upload.php       # API key management
├── assets/
│   ├── css/admin.css        # Admin interface styles
│   └── js/admin.js          # Admin interface scripts
├── smart-indexing-pro.php   # Main plugin file
└── README.md               # This file
```

## Database Tables

The plugin creates the following tables:
- `wp_sip_api_keys` - Stores API credentials and usage tracking
- `wp_sip_indexing_queue` - Manages submission queue
- `wp_sip_indexing_status` - Tracks indexing status per post
- `wp_sip_logs` - Activity and error logging

## API Limits

- **Google Indexing API**: 200 requests per day per service account
- **Bing Webmaster Tools**: 1000 requests per day (configurable)
- **Yandex Webmaster**: 500 requests per day (configurable)

## Troubleshooting

### Common Issues

1. **Google API Errors**
   - Verify service account has Indexing API permissions
   - Check JSON format and required fields
   - Ensure quota isn't exhausted

2. **Bing API Errors**
   - Verify site is registered in Bing Webmaster Tools
   - Check API key validity
   - Ensure proper OAuth setup

3. **Queue Not Processing**
   - Check if WP-Cron is working
   - Verify plugin is enabled in settings
   - Review error logs for API issues

### Debug Mode
Enable debug mode in Settings → General to get detailed logging of all operations.

## Support

For support and updates, visit [your-website.com/smart-indexing-pro](https://your-website.com/smart-indexing-pro)

## License

This plugin is licensed under the GPL v2 or later.

## Changelog

### Version 1.0.0
- Initial release
- Google Indexing API support with key rotation
- Bing and Yandex API integration
- Comprehensive dashboard and management interface
- Automated queue processing and status tracking
```