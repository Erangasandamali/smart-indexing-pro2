<?php
if (!defined('ABSPATH')) {
    exit;
}

class SIP_Queue_Manager {
    
    private $table_name;
    
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'sip_queue';
    }
    
    public function add_url_to_queue($url, $post_id = null) {
        global $wpdb;
        
        // Check if URL already exists in queue
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$this->table_name} WHERE url = %s AND status IN ('pending', 'processing')",
            $url
        ));
        
        if ($existing) {
            return array('success' => false, 'message' => 'URL already in queue');
        }
        
        $result = $wpdb->insert(
            $this->table_name,
            array(
                'url' => esc_url_raw($url),
                'post_id' => $post_id,
                'status' => 'pending',
                'retry_count' => 0,
                'created_at' => current_time('mysql')
            ),
            array('%s', '%d', '%s', '%d', '%s')
        );
        
        if ($result) {
            // Immediately try to process this URL
            $this->process_single_url($wpdb->insert_id);
            return array('success' => true, 'message' => 'URL added to queue successfully');
        } else {
            return array('success' => false, 'message' => 'Failed to add URL to queue');
        }
    }
    
    public function get_queue_items($limit = 50, $offset = 0) {
        global $wpdb;
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT q.*, p.post_title 
             FROM {$this->table_name} q 
             LEFT JOIN {$wpdb->posts} p ON q.post_id = p.ID 
             ORDER BY q.created_at DESC 
             LIMIT %d OFFSET %d",
            $limit, $offset
        ));
        
        return $results;
    }
    
    public function get_filtered_queue_items($status_filter = '', $post_type_filter = '', $url_search = '', $limit = 50) {
        global $wpdb;
        
        $where_clauses = array();
        $params = array();
        
        if (!empty($status_filter)) {
            $where_clauses[] = "q.status = %s";
            $params[] = $status_filter;
        }
        
        if (!empty($post_type_filter)) {
            $where_clauses[] = "p.post_type = %s";
            $params[] = $post_type_filter;
        }
        
        if (!empty($url_search)) {
            $where_clauses[] = "q.url LIKE %s";
            $params[] = '%' . $wpdb->esc_like($url_search) . '%';
        }
        
        $where_sql = '';
        if (!empty($where_clauses)) {
            $where_sql = 'WHERE ' . implode(' AND ', $where_clauses);
        }
        
        $params[] = $limit;
        
        $sql = "SELECT q.*, p.post_title 
                FROM {$this->table_name} q 
                LEFT JOIN {$wpdb->posts} p ON q.post_id = p.ID 
                {$where_sql}
                ORDER BY q.created_at DESC 
                LIMIT %d";
        
        return $wpdb->get_results($wpdb->prepare($sql, $params));
    }
    
    public function process_queue($batch_size = 10) {
        global $wpdb;
        
        $settings = get_option('sip_settings', array());
        $max_retries = isset($settings['max_retry_attempts']) ? $settings['max_retry_attempts'] : 10;
        
        // Get pending items
        $items = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_name} 
             WHERE status = 'pending' AND retry_count < %d 
             ORDER BY created_at ASC 
             LIMIT %d",
            $max_retries, $batch_size
        ));
        
        foreach ($items as $item) {
            $this->process_single_url($item->id);
        }
    }
    
    public function process_single_url($queue_id) {
        global $wpdb;
        
        // Get queue item
        $item = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d",
            $queue_id
        ));
        
        if (!$item) {
            return false;
        }
        
        // Mark as processing
        $wpdb->update(
            $this->table_name,
            array('status' => 'processing', 'last_attempt' => current_time('mysql')),
            array('id' => $queue_id)
        );
        
        // Get available API key
        $api_manager = new SIP_API_Manager();
        $api_key = $api_manager->get_available_api_key();
        
        if (!$api_key) {
            // No available API keys
            $wpdb->update(
                $this->table_name,
                array('status' => 'failed'),
                array('id' => $queue_id)
            );
            
            $logger = new SIP_Logger();
            $logger->log($item->url, null, 'submit', 'error', 'No available API keys');
            
            // Trigger quota exceeded notification
            do_action('sip_quota_exceeded', 'All API Keys');
            
            return false;
        }
        
        // Submit to Google Indexing API
        $google_checker = new SIP_Google_Checker();
        $result = $google_checker->submit_url($item->url, $api_key);
        
        if ($result['success']) {
            // Mark as completed
            $wpdb->update(
                $this->table_name,
                array('status' => 'completed'),
                array('id' => $queue_id)
            );
            
            // Increment API key usage
            $api_manager->increment_usage($api_key->id);
            
            // Log success
            $logger = new SIP_Logger();
            $logger->log($item->url, $api_key->id, 'submit', 'success', $result['message']);
            
        } else {
            // Increment retry count
            $new_retry_count = $item->retry_count + 1;
            $settings = get_option('sip_settings', array());
            $max_retries = isset($settings['max_retry_attempts']) ? $settings['max_retry_attempts'] : 10;
            
            if ($new_retry_count >= $max_retries) {
                $status = 'failed';
                // Trigger failure notification
                do_action('sip_submission_failed', $item->url, $result['message']);
            } else {
                $status = 'pending';
            }
            
            $wpdb->update(
                $this->table_name,
                array(
                    'status' => $status,
                    'retry_count' => $new_retry_count
                ),
                array('id' => $queue_id)
            );
            
            // Log failure
            $logger = new SIP_Logger();
            $logger->log($item->url, $api_key ? $api_key->id : null, 'submit', 'error', $result['message']);
        }
        
        return $result['success'];
    }
    
    public function remove_url_from_queue($url) {
        global $wpdb;
        
        $result = $wpdb->delete(
            $this->table_name,
            array('url' => $url),
            array('%s')
        );
        
        return $result !== false;
    }
    
    public function reindex_url($url) {
        global $wpdb;
        
        // Reset the URL status to pending
        $result = $wpdb->update(
            $this->table_name,
            array(
                'status' => 'pending',
                'retry_count' => 0,
                'last_attempt' => null
            ),
            array('url' => $url),
            array('%s', '%d', '%s'),
            array('%s')
        );
        
        if ($result !== false) {
            // Try to process immediately
            $queue_item = $wpdb->get_row($wpdb->prepare(
                "SELECT id FROM {$this->table_name} WHERE url = %s",
                $url
            ));
            
            if ($queue_item) {
                $this->process_single_url($queue_item->id);
            }
        }
        
        return $result !== false;
    }
    
    public function get_queue_stats() {
        global $wpdb;
        
        $stats = array(
            'total' => $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name}"),
            'pending' => $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name} WHERE status = 'pending'"),
            'processing' => $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name} WHERE status = 'processing'"),
            'completed' => $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name} WHERE status = 'completed'"),
            'failed' => $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name} WHERE status = 'failed'")
        );
        
        return $stats;
    }
    
    public function clean_old_entries($days = 30) {
        global $wpdb;
        
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$this->table_name} WHERE status = 'completed' AND created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ));
    }
}