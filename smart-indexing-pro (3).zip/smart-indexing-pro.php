<?php
/**
 * Plugin Name: Smart Indexing Pro
 * Plugin URI: https://smartindexing.pro
 * Description: Advanced WordPress plugin for automated URL indexing across Google, Bing, and Yandex with API key rotation and comprehensive monitoring.
 * Version: 1.0.0
 * Author: Smart Indexing Pro Team
 * License: GPL v2 or later
 * Text Domain: smart-indexing-pro
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('SIP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('SIP_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('SIP_VERSION', '1.0.0');

class SmartIndexingPro {
    
    public function __construct() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        register_uninstall_hook(__FILE__, array('SmartIndexingPro', 'uninstall'));
        
        add_action('init', array($this, 'init'));
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'admin_scripts'));
        
        // AJAX handlers
        add_action('wp_ajax_sip_upload_api_key', array($this, 'ajax_upload_api_key'));
        add_action('wp_ajax_sip_submit_url', array($this, 'ajax_submit_url'));
        add_action('wp_ajax_sip_delete_api_key', array($this, 'ajax_delete_api_key'));
        add_action('wp_ajax_sip_reindex_url', array($this, 'ajax_reindex_url'));
        add_action('wp_ajax_sip_remove_url', array($this, 'ajax_remove_url'));
        add_action('wp_ajax_sip_get_recent_activity', array($this, 'ajax_get_recent_activity'));
        add_action('wp_ajax_sip_get_dashboard_stats', array($this, 'ajax_get_dashboard_stats'));
        
        // Auto-submit new posts
        add_action('transition_post_status', array($this, 'auto_submit_post'), 10, 3);
        
        // Schedule daily tasks
        add_action('sip_daily_tasks', array($this, 'run_daily_tasks'));
        if (!wp_next_scheduled('sip_daily_tasks')) {
            wp_schedule_event(time(), 'daily', 'sip_daily_tasks');
        }
        
        // Initialize advanced features
        add_action('init', array($this, 'init_advanced_features'));
    }
    
    public function init() {
        $this->load_includes();
    }
    
    public function init_advanced_features() {
        // Initialize REST API
        new SIP_REST_API();
        
        // Initialize Multisite Manager
        if (is_multisite()) {
            new SIP_Multisite_Manager();
        }
        
        // Initialize Notification Manager
        new SIP_Notification_Manager();
        
        // Initialize Cloudflare Worker
        new SIP_Cloudflare_Worker();
    }
    
    private function load_includes() {
        require_once SIP_PLUGIN_PATH . 'includes/api-manager.php';
        require_once SIP_PLUGIN_PATH . 'includes/queue-manager.php';
        require_once SIP_PLUGIN_PATH . 'includes/checker-google.php';
        require_once SIP_PLUGIN_PATH . 'includes/checker-bing.php';
        require_once SIP_PLUGIN_PATH . 'includes/checker-yandex.php';
        require_once SIP_PLUGIN_PATH . 'includes/logger.php';
        
        // Load advanced features
        require_once SIP_PLUGIN_PATH . 'includes/rest-api.php';
        require_once SIP_PLUGIN_PATH . 'includes/multisite-manager.php';
        require_once SIP_PLUGIN_PATH . 'includes/notification-manager.php';
        require_once SIP_PLUGIN_PATH . 'includes/cloudflare-worker.php';
    }
    
    public function activate() {
        $this->create_tables();
        $this->set_default_options();
        flush_rewrite_rules();
    }
    
    public function deactivate() {
        wp_clear_scheduled_hook('sip_daily_tasks');
    }
    
    public static function uninstall() {
        global $wpdb;
        
        // Drop custom tables
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}sip_api_keys");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}sip_queue");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}sip_logs");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}sip_indexing_status");
        
        // Delete options
        delete_option('sip_settings');
        delete_option('sip_version');
        
        // Clear scheduled events
        wp_clear_scheduled_hook('sip_daily_tasks');
    }
    
    private function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // API Keys table
        $sql1 = "CREATE TABLE {$wpdb->prefix}sip_api_keys (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            json_content longtext NOT NULL,
            usage_today int(11) DEFAULT 0,
            last_used datetime DEFAULT NULL,
            status enum('active','disabled','quota_exceeded') DEFAULT 'active',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        // Queue table
        $sql2 = "CREATE TABLE {$wpdb->prefix}sip_queue (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            url varchar(500) NOT NULL,
            post_id int(11) DEFAULT NULL,
            post_title varchar(255) DEFAULT NULL,
            status enum('pending','processing','completed','failed') DEFAULT 'pending',
            retry_count int(11) DEFAULT 0,
            last_attempt datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY url_index (url),
            KEY status_index (status)
        ) $charset_collate;";
        
        // Logs table
        $sql3 = "CREATE TABLE {$wpdb->prefix}sip_logs (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            url varchar(500) NOT NULL,
            api_key_id int(11) DEFAULT NULL,
            api_key_name varchar(255) DEFAULT NULL,
            action varchar(100) NOT NULL,
            status varchar(50) NOT NULL,
            message text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY url_index (url),
            KEY created_at_index (created_at)
        ) $charset_collate;";
        
        // Indexing status table
        $sql4 = "CREATE TABLE {$wpdb->prefix}sip_indexing_status (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            post_id int(11) NOT NULL,
            url varchar(500) NOT NULL,
            google_status enum('unknown','indexed','not_indexed','error') DEFAULT 'unknown',
            bing_status enum('unknown','indexed','not_indexed','error') DEFAULT 'unknown',
            yandex_status enum('unknown','indexed','not_indexed','error') DEFAULT 'unknown',
            last_checked datetime DEFAULT NULL,
            retry_count int(11) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY post_id_unique (post_id),
            KEY url_index (url)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql1);
        dbDelta($sql2);
        dbDelta($sql3);
        dbDelta($sql4);
    }
    
    private function set_default_options() {
        $default_settings = array(
            'auto_submit_on_publish' => 1,
            'retry_frequency' => 6,
            'max_retry_attempts' => 10,
            'enable_bing' => 0,
            'enable_yandex' => 0,
            'post_types' => array('post', 'page'),
            'email_notifications' => 0,
            'notification_email' => get_option('admin_email')
        );
        
        update_option('sip_settings', $default_settings);
        update_option('sip_version', SIP_VERSION);
    }
    
    public function admin_menu() {
        add_menu_page(
            'Smart Indexing Pro',
            'Smart Indexing',
            'manage_options',
            'smart-indexing-pro',
            array($this, 'admin_dashboard'),
            'dashicons-search',
            30
        );
        
        add_submenu_page(
            'smart-indexing-pro',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'smart-indexing-pro',
            array($this, 'admin_dashboard')
        );
        
        add_submenu_page(
            'smart-indexing-pro',
            'API Keys',
            'API Keys',
            'manage_options',
            'sip-api-keys',
            array($this, 'admin_api_keys')
        );
        
        add_submenu_page(
            'smart-indexing-pro',
            'URL Queue',
            'URL Queue',
            'manage_options',
            'sip-queue',
            array($this, 'admin_queue')
        );
        
        add_submenu_page(
            'smart-indexing-pro',
            'Logs',
            'Logs',
            'manage_options',
            'sip-logs',
            array($this, 'admin_logs')
        );
        
        add_submenu_page(
            'smart-indexing-pro',
            'Settings',
            'Settings',
            'manage_options',
            'sip-settings',
            array($this, 'admin_settings')
        );
        
        add_submenu_page(
            'smart-indexing-pro',
            'Advanced Features',
            'Advanced Features',
            'manage_options',
            'sip-advanced',
            array($this, 'admin_advanced')
        );
    }
    
    public function admin_scripts($hook) {
        // Only load on our plugin pages
        if (strpos($hook, 'smart-indexing') === false && strpos($hook, 'sip-') === false) {
            return;
        }
        
        $version = SIP_VERSION . '.' . time();
        
        wp_enqueue_style(
            'sip-admin-css', 
            SIP_PLUGIN_URL . 'assets/css/admin.css', 
            array(), 
            $version
        );
        
        wp_enqueue_script(
            'sip-admin-js', 
            SIP_PLUGIN_URL . 'assets/js/admin.js', 
            array('jquery'), 
            $version, 
            true
        );
        
        wp_localize_script('sip-admin-js', 'sip_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('sip_nonce'),
            'plugin_url' => SIP_PLUGIN_URL
        ));
    }
    
    public function admin_dashboard() {
        require_once SIP_PLUGIN_PATH . 'admin/dashboard.php';
    }
    
    public function admin_api_keys() {
        require_once SIP_PLUGIN_PATH . 'admin/api-keys.php';
    }
    
    public function admin_queue() {
        require_once SIP_PLUGIN_PATH . 'admin/queue.php';
    }
    
    public function admin_logs() {
        require_once SIP_PLUGIN_PATH . 'admin/logs.php';
    }
    
    public function admin_settings() {
        require_once SIP_PLUGIN_PATH . 'admin/settings.php';
    }
    
    public function admin_advanced() {
        require_once SIP_PLUGIN_PATH . 'admin/advanced.php';
    }
    
    // AJAX Handlers with improved error handling and logging
    public function ajax_upload_api_key() {
        error_log('SIP: ajax_upload_api_key called with data: ' . print_r($_POST, true));
        
        // Check if required classes exist
        if (!class_exists('SIP_API_Manager')) {
            error_log('SIP: SIP_API_Manager class not found');
            wp_send_json_error(array('message' => 'Plugin not properly initialized'));
            return;
        }
        
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'sip_nonce')) {
            error_log('SIP: Nonce verification failed');
            wp_send_json_error(array('message' => 'Security check failed'));
            return;
        }
        
        if (!current_user_can('manage_options')) {
            error_log('SIP: User does not have manage_options capability');
            wp_send_json_error(array('message' => 'Unauthorized access'));
            return;
        }
        
        $key_name = isset($_POST['key_name']) ? sanitize_text_field($_POST['key_name']) : '';
        $json_content = isset($_POST['json_content']) ? wp_unslash($_POST['json_content']) : '';
        
        error_log('SIP: Processing upload - Key name: ' . $key_name . ', JSON length: ' . strlen($json_content));
        
        if (empty($key_name) || empty($json_content)) {
            wp_send_json_error(array('message' => 'Key name and JSON content are required'));
            return;
        }
        
        $api_manager = new SIP_API_Manager();
        $result = $api_manager->upload_api_key($key_name, $json_content);
        
        error_log('SIP: Upload result: ' . print_r($result, true));
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    public function ajax_submit_url() {
        error_log('SIP: ajax_submit_url called with URL: ' . (isset($_POST['url']) ? $_POST['url'] : 'none'));
        
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'sip_nonce')) {
            wp_send_json_error(array('message' => 'Security check failed'));
            return;
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Unauthorized access'));
            return;
        }
        
        $url = isset($_POST['url']) ? esc_url_raw($_POST['url']) : '';
        if (!$url || !filter_var($url, FILTER_VALIDATE_URL)) {
            wp_send_json_error(array('message' => 'Invalid URL provided'));
            return;
        }
        
        error_log('SIP: Processing URL submission: ' . $url);
        
        if (!class_exists('SIP_Queue_Manager')) {
            error_log('SIP: SIP_Queue_Manager class not found');
            wp_send_json_error(array('message' => 'Plugin not properly initialized'));
            return;
        }
        
        $queue_manager = new SIP_Queue_Manager();
        $result = $queue_manager->add_url_to_queue($url);
        
        error_log('SIP: Submit URL result: ' . print_r($result, true));
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    public function ajax_delete_api_key() {
        error_log('SIP: ajax_delete_api_key called with key_id: ' . (isset($_POST['key_id']) ? $_POST['key_id'] : 'none'));
        
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'sip_nonce')) {
            wp_send_json_error(array('message' => 'Security check failed'));
            return;
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Unauthorized access'));
            return;
        }
        
        $key_id = isset($_POST['key_id']) ? intval($_POST['key_id']) : 0;
        if (!$key_id) {
            wp_send_json_error(array('message' => 'Invalid key ID'));
            return;
        }
        
        if (!class_exists('SIP_API_Manager')) {
            wp_send_json_error(array('message' => 'Plugin not properly initialized'));
            return;
        }
        
        $api_manager = new SIP_API_Manager();
        $result = $api_manager->delete_api_key($key_id);
        
        error_log('SIP: Delete API key result: ' . print_r($result, true));
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    public function ajax_reindex_url() {
        error_log('SIP: ajax_reindex_url called with URL: ' . (isset($_POST['url']) ? $_POST['url'] : 'none'));
        
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'sip_nonce')) {
            wp_send_json_error(array('message' => 'Security check failed'));
            return;
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Unauthorized access'));
            return;
        }
        
        $url = isset($_POST['url']) ? esc_url_raw($_POST['url']) : '';
        if (!$url) {
            wp_send_json_error(array('message' => 'URL is required'));
            return;
        }
        
        if (!class_exists('SIP_Queue_Manager')) {
            wp_send_json_error(array('message' => 'Plugin not properly initialized'));
            return;
        }
        
        $queue_manager = new SIP_Queue_Manager();
        $result = $queue_manager->reindex_url($url);
        
        error_log('SIP: Reindex URL result: ' . ($result ? 'success' : 'failed'));
        
        if ($result) {
            wp_send_json_success(array('message' => 'URL queued for reindexing'));
        } else {
            wp_send_json_error(array('message' => 'Failed to queue URL for reindexing'));
        }
    }
    
    public function ajax_remove_url() {
        error_log('SIP: ajax_remove_url called with URL: ' . (isset($_POST['url']) ? $_POST['url'] : 'none'));
        
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'sip_nonce')) {
            wp_send_json_error(array('message' => 'Security check failed'));
            return;
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Unauthorized access'));
            return;
        }
        
        $url = isset($_POST['url']) ? esc_url_raw($_POST['url']) : '';
        if (!$url) {
            wp_send_json_error(array('message' => 'URL is required'));
            return;
        }
        
        if (!class_exists('SIP_Queue_Manager')) {
            wp_send_json_error(array('message' => 'Plugin not properly initialized'));
            return;
        }
        
        $queue_manager = new SIP_Queue_Manager();
        $result = $queue_manager->remove_url_from_queue($url);
        
        error_log('SIP: Remove URL result: ' . ($result ? 'success' : 'failed'));
        
        if ($result) {
            wp_send_json_success(array('message' => 'URL removed from queue'));
        } else {
            wp_send_json_error(array('message' => 'Failed to remove URL from queue'));
        }
    }
    
    public function ajax_get_recent_activity() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'sip_nonce')) {
            wp_send_json_error(array('message' => 'Security check failed'));
            return;
        }
        
        global $wpdb;
        $logs = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}sip_logs ORDER BY created_at DESC LIMIT 10");
        wp_send_json_success($logs);
    }
    
    public function ajax_get_dashboard_stats() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'sip_nonce')) {
            wp_send_json_error(array('message' => 'Security check failed'));
            return;
        }
        
        wp_send_json_success(array(
            'indexing_rate' => 85,
            'api_usage' => 45
        ));
    }
    
    public function auto_submit_post($new_status, $old_status, $post) {
        $settings = get_option('sip_settings', array());
        
        if (!isset($settings['auto_submit_on_publish']) || !$settings['auto_submit_on_publish']) {
            return;
        }
        
        if ($new_status === 'publish' && $old_status !== 'publish') {
            $post_types = isset($settings['post_types']) ? $settings['post_types'] : array('post', 'page');
            
            if (in_array($post->post_type, $post_types)) {
                $url = get_permalink($post->ID);
                if (class_exists('SIP_Queue_Manager')) {
                    $queue_manager = new SIP_Queue_Manager();
                    $queue_manager->add_url_to_queue($url, $post->ID);
                }
            }
        }
    }
    
    public function run_daily_tasks() {
        if (class_exists('SIP_API_Manager')) {
            $api_manager = new SIP_API_Manager();
            $api_manager->reset_daily_quotas();
        }
        
        if (class_exists('SIP_Logger')) {
            $logger = new SIP_Logger();
            $logger->clean_old_logs(30);
        }
        
        if (class_exists('SIP_Queue_Manager')) {
            $queue_manager = new SIP_Queue_Manager();
            $queue_manager->clean_old_entries(30);
        }
    }
}

// Initialize the plugin
new SmartIndexingPro();