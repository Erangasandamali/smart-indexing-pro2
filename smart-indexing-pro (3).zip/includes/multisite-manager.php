<?php
if (!defined('ABSPATH')) {
    exit;
}

class SIP_Multisite_Manager {
    
    public function __construct() {
        if (is_multisite()) {
            add_action('wp_initialize_site', array($this, 'setup_new_site'));
            add_action('wp_delete_site', array($this, 'cleanup_site'));
            add_filter('sip_get_site_settings', array($this, 'get_site_specific_settings'));
        }
    }
    
    public function setup_new_site($new_site) {
        if (!is_multisite()) {
            return;
        }
        
        switch_to_blog($new_site->blog_id);
        
        // Create tables for new site
        $this->create_site_tables();
        
        // Set default settings for new site
        $this->set_default_site_settings();
        
        restore_current_blog();
    }
    
    public function cleanup_site($old_site) {
        if (!is_multisite()) {
            return;
        }
        
        global $wpdb;
        
        // Clean up site-specific data
        $wpdb->delete($wpdb->prefix . 'sip_api_keys', array('blog_id' => $old_site->blog_id));
        $wpdb->delete($wpdb->prefix . 'sip_queue', array('blog_id' => $old_site->blog_id));
        $wpdb->delete($wpdb->prefix . 'sip_logs', array('blog_id' => $old_site->blog_id));
        $wpdb->delete($wpdb->prefix . 'sip_indexing_status', array('blog_id' => $old_site->blog_id));
    }
    
    private function create_site_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Add blog_id column to existing tables for multisite support
        $tables_to_modify = array(
            $wpdb->prefix . 'sip_api_keys',
            $wpdb->prefix . 'sip_queue',
            $wpdb->prefix . 'sip_logs',
            $wpdb->prefix . 'sip_indexing_status'
        );
        
        foreach ($tables_to_modify as $table) {
            $column_exists = $wpdb->get_results("SHOW COLUMNS FROM {$table} LIKE 'blog_id'");
            if (empty($column_exists)) {
                $wpdb->query("ALTER TABLE {$table} ADD COLUMN blog_id INT(11) DEFAULT 1");
            }
        }
    }
    
    private function set_default_site_settings() {
        $default_settings = array(
            'auto_submit_on_publish' => 1,
            'retry_frequency' => 6,
            'max_retry_attempts' => 10,
            'enable_bing' => 0,
            'enable_yandex' => 0,
            'post_types' => array('post', 'page'),
            'email_notifications' => 0,
            'notification_email' => get_option('admin_email'),
            'multisite_enabled' => 1
        );
        
        update_option('sip_settings', $default_settings);
    }
    
    public function get_site_specific_settings($settings) {
        if (is_multisite()) {
            $blog_id = get_current_blog_id();
            $site_settings = get_blog_option($blog_id, 'sip_settings', array());
            return array_merge($settings, $site_settings);
        }
        
        return $settings;
    }
    
    public function get_all_sites_stats() {
        if (!is_multisite()) {
            return array();
        }
        
        $sites = get_sites();
        $stats = array();
        
        foreach ($sites as $site) {
            switch_to_blog($site->blog_id);
            
            $queue_manager = new SIP_Queue_Manager();
            $api_manager = new SIP_API_Manager();
            
            $stats[$site->blog_id] = array(
                'site_name' => get_bloginfo('name'),
                'site_url' => get_site_url(),
                'queue_stats' => $queue_manager->get_queue_stats(),
                'total_keys' => $api_manager->get_total_keys(),
                'active_keys' => $api_manager->get_active_keys_count(),
                'usage_today' => $api_manager->get_total_usage_today()
            );
            
            restore_current_blog();
        }
        
        return $stats;
    }
}