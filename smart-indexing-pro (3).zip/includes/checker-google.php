<?php
if (!defined('ABSPATH')) {
    exit;
}

class SIP_Google_Checker {
    
    private $indexing_table;
    
    public function __construct() {
        global $wpdb;
        $this->indexing_table = $wpdb->prefix . 'sip_indexing_status';
    }
    
    public function submit_url($url, $api_key) {
        try {
            // Decode the JSON key
            $key_data = json_decode($api_key->json_content, true);
            
            if (!$key_data) {
                return array('success' => false, 'message' => 'Invalid API key format');
            }
            
            // Create JWT token
            $jwt = $this->create_jwt($key_data);
            
            // Get access token
            $access_token = $this->get_access_token($jwt);
            
            if (!$access_token) {
                return array('success' => false, 'message' => 'Failed to get access token');
            }
            
            // Submit URL to Google Indexing API
            $response = $this->call_indexing_api($url, $access_token);
            
            if ($response['success']) {
                // Update indexing status
                $this->update_indexing_status($url, 'unknown', 'google');
                return array('success' => true, 'message' => 'URL submitted successfully');
            } else {
                return array('success' => false, 'message' => $response['message']);
            }
            
        } catch (Exception $e) {
            return array('success' => false, 'message' => 'Error: ' . $e->getMessage());
        }
    }
    
    public function check_indexing_status($url) {
        // Simple check using site: operator
        $search_url = 'https://www.google.com/search?q=site:' . urlencode($url);
        
        $response = wp_remote_get($search_url, array(
            'timeout' => 30,
            'user-agent' => 'Mozilla/5.0 (compatible; WordPress Smart Indexing Pro)'
        ));
        
        if (is_wp_error($response)) {
            return array('status' => 'error', 'message' => $response->get_error_message());
        }
        
        $body = wp_remote_retrieve_body($response);
        
        // Check if URL appears in results
        if (strpos($body, 'did not match any documents') !== false) {
            $status = 'not_indexed';
        } elseif (strpos($body, $url) !== false) {
            $status = 'indexed';
        } else {
            $status = 'unknown';
        }
        
        // Update status in database
        $this->update_indexing_status($url, $status, 'google');
        
        return array('status' => $status, 'message' => 'Status checked successfully');
    }
    
    public function check_pending_urls() {
        global $wpdb;
        
        // Get URLs that haven't been checked recently
        $urls = $wpdb->get_results("
            SELECT url FROM {$this->indexing_table} 
            WHERE google_status IN ('unknown', 'not_indexed') 
            AND (last_checked IS NULL OR last_checked < DATE_SUB(NOW(), INTERVAL 1 DAY))
            LIMIT 20
        ");
        
        foreach ($urls as $url_obj) {
            $this->check_indexing_status($url_obj->url);
            // Add small delay to avoid rate limiting
            sleep(1);
        }
    }
    
    private function create_jwt($key_data) {
        $header = json_encode(array('typ' => 'JWT', 'alg' => 'RS256'));
        $payload = json_encode(array(
            'iss' => $key_data['client_email'],
            'scope' => 'https://www.googleapis.com/auth/indexing',
            'aud' => 'https://oauth2.googleapis.com/token',
            'iat' => time(),
            'exp' => time() + 3600
        ));
        
        $base64Header = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
        $base64Payload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));
        
        $signature = '';
        openssl_sign($base64Header . "." . $base64Payload, $signature, $key_data['private_key'], 'SHA256');
        $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
        
        return $base64Header . "." . $base64Payload . "." . $base64Signature;
    }
    
    private function get_access_token($jwt) {
        $response = wp_remote_post('https://oauth2.googleapis.com/token', array(
            'body' => array(
                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion' => $jwt
            ),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return false;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        return isset($body['access_token']) ? $body['access_token'] : false;
    }
    
    private function call_indexing_api($url, $access_token) {
        $api_url = 'https://indexing.googleapis.com/v3/urlNotifications:publish';
        
        $response = wp_remote_post($api_url, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $access_token,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'url' => $url,
                'type' => 'URL_UPDATED'
            )),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return array('success' => false, 'message' => $response->get_error_message());
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        
        if ($status_code === 200) {
            return array('success' => true, 'message' => 'URL submitted successfully');
        } else {
            $body = wp_remote_retrieve_body($response);
            return array('success' => false, 'message' => 'API Error: ' . $body);
        }
    }
    
    private function update_indexing_status($url, $status, $engine) {
        global $wpdb;
        
        // Get post ID from URL
        $post_id = url_to_postid($url);
        
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->indexing_table} WHERE url = %s",
            $url
        ));
        
        if ($existing) {
            $update_data = array(
                'last_checked' => current_time('mysql'),
                'updated_at' => current_time('mysql')
            );
            
            if ($engine === 'google') {
                $update_data['google_status'] = $status;
            }
            
            $wpdb->update(
                $this->indexing_table,
                $update_data,
                array('url' => $url)
            );
        } else {
            $insert_data = array(
                'post_id' => $post_id,
                'url' => $url,
                'last_checked' => current_time('mysql'),
                'created_at' => current_time('mysql')
            );
            
            if ($engine === 'google') {
                $insert_data['google_status'] = $status;
            }
            
            $wpdb->insert($this->indexing_table, $insert_data);
        }
    }
}