<?php
if (!defined('ABSPATH')) {
    exit;
}

$api_manager = new SIP_API_Manager();
$api_keys = $api_manager->get_api_keys();
?>

<div class="wrap">
    <div class="sip-dashboard">
        <h1 class="sip-page-title">
            <span class="dashicons dashicons-admin-network"></span>
            API Keys Management
        </h1>
        
        <div class="sip-info-box">
            <h3>Smart Indexing Pro uses Google Indexing API for URL submission. Each key has a daily quota of 200 submission requests.</h3>
            <p><strong>Important:</strong> You need to create service account keys in the Google Cloud Console with the "Indexing API" scope enabled.</p>
        </div>
        
        <!-- Upload New API Key Section -->
        <div class="sip-card">
            <div class="sip-card-header">
                <h2><span class="dashicons dashicons-upload"></span> Upload New API Key</h2>
                <div class="sip-card-subtitle">Add a new Google Service Account JSON key</div>
            </div>
            <div class="sip-card-content">
                <form id="upload-api-key-form">
                    <div class="sip-form-group">
                        <label for="key-name">Key Name</label>
                        <input type="text" id="key-name" name="key_name" placeholder="A friendly name to identify this key" class="sip-input" required>
                    </div>
                    
                    <div class="sip-form-group">
                        <label for="json-file">JSON Key File</label>
                        <div class="sip-file-upload">
                            <input type="file" id="json-file" accept=".json" style="display: none;">
                            <button type="button" id="choose-file-btn" class="sip-btn sip-btn-secondary">
                                <span class="dashicons dashicons-media-default"></span> Choose File
                            </button>
                            <span id="file-name">No file chosen</span>
                        </div>
                        <p class="sip-help-text">Upload the JSON key file from Google Cloud Console</p>
                    </div>
                    
                    <button type="submit" id="upload-api-key" class="sip-btn sip-btn-primary">
                        <span class="dashicons dashicons-upload"></span> Upload API Key
                    </button>
                </form>
            </div>
        </div>
        
        <!-- Existing API Keys Section -->
        <div class="sip-section">
            <h2><span class="dashicons dashicons-admin-network"></span> Existing API Keys</h2>
            <div class="sip-table-container">
                <table class="sip-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Usage Today</th>
                            <th>Last Used</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($api_keys): ?>
                            <?php foreach ($api_keys as $key): ?>
                                <tr>
                                    <td><strong><?php echo esc_html($key->name); ?></strong></td>
                                    <td>
                                        <div class="sip-usage-indicator">
                                            <span><?php echo $key->usage_today; ?> / 200</span>
                                            <div class="sip-progress">
                                                <div class="sip-progress-fill" style="width: <?php echo min(($key->usage_today / 200) * 100, 100); ?>%"></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo $key->last_used ? date('M j, Y H:i', strtotime($key->last_used)) : 'Never'; ?></td>
                                    <td>
                                        <?php
                                        $status_class = '';
                                        $status_text = ucfirst(str_replace('_', ' ', $key->status));
                                        
                                        if ($key->status === 'active') {
                                            $status_class = 'sip-status-success';
                                        } elseif ($key->status === 'quota_exceeded') {
                                            $status_class = 'sip-status-warning';
                                        } else {
                                            $status_class = 'sip-status-error';
                                        }
                                        ?>
                                        <span class="sip-status <?php echo $status_class; ?>"><?php echo $status_text; ?></span>
                                    </td>
                                    <td>
                                        <button class="sip-btn sip-btn-small sip-btn-danger delete-key" data-key-id="<?php echo $key->id; ?>">
                                            <span class="dashicons dashicons-trash"></span> Delete
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="sip-no-data">No API keys found. Upload your first API key to get started.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
