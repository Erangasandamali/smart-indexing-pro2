<?php
if (!defined('ABSPATH')) {
    exit;
}

// Get statistics
$api_manager = new SIP_API_Manager();
$queue_manager = new SIP_Queue_Manager();
$logger = new SIP_Logger();

$api_keys = $api_manager->get_api_keys();
$queue_stats = $queue_manager->get_queue_stats();
$log_stats = $logger->get_log_stats();
$total_usage = $api_manager->get_total_usage_today();
$total_keys = $api_manager->get_total_keys();

// Calculate indexing rate
$google_indexing_rate = 0;
if (($log_stats['successful_submissions'] + $log_stats['failed_submissions']) > 0) {
    $google_indexing_rate = round(($log_stats['successful_submissions'] / ($log_stats['successful_submissions'] + $log_stats['failed_submissions'])) * 100);
}

// Calculate API usage percentage
$api_usage_percentage = 0;
if ($total_keys > 0) {
    $api_usage_percentage = round(($total_usage / ($total_keys * 200)) * 100);
}
?>
<style>/* Smart Indexing Pro Admin Styles */
.sip-dashboard,
.sip-api-keys,
.sip-queue,
.sip-logs,
.sip-settings {
    margin: 20px 0;
}

.sip-page-title {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 24px;
    font-weight: 600;
    margin-bottom: 20px;
    color: #1e293b;
}

.sip-page-title .dashicons {
    color: #3b82f6;
}

/* Dashboard Grid */
.sip-dashboard-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

/* Cards */
.sip-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    overflow: hidden;
}

.sip-card-header {
    padding: 16px 20px;
    border-bottom: 1px solid #e2e8f0;
    background: #f8fafc;
}

.sip-card-header h2 {
    margin: 0;
    font-size: 16px;
    font-weight: 600;
    color: #1e293b;
}

.sip-card-subtitle {
    font-size: 12px;
    color: #64748b;
    margin-top: 4px;
    display: block;
}

.sip-card-content {
    padding: 20px;
}

/* Metrics */
.sip-metric-large {
    font-size: 36px;
    font-weight: 700;
    color: #1e293b;
    margin-bottom: 10px;
}

.sip-metric-details {
    font-size: 13px;
    color: #64748b;
    line-height: 1.4;
}

.sip-metric-details div {
    margin-bottom: 2px;
}

/* Quick Actions */
.sip-quick-actions {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
    flex-wrap: wrap;
}

.sip-manual-submit {
    margin-top: 20px;
}

.sip-manual-submit label {
    display: block;
    margin-bottom: 8px;
    font-weight: 500;
    color: #374151;
}

.sip-input-group {
    display: flex;
    gap: 10px;
}

.sip-input-group .sip-input {
    flex: 1;
}

/* Buttons */
.sip-btn {
    display: inline-block;
    padding: 8px 16px;
    border: none;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.2s;
    line-height: 1.4;
}

.sip-btn-primary {
    background: #3b82f6;
    color: white;
}

.sip-btn-primary:hover {
    background: #2563eb;
    color: white;
}

.sip-btn-secondary {
    background: #f1f5f9;
    color: #475569;
    border: 1px solid #e2e8f0;
}

.sip-btn-secondary:hover {
    background: #e2e8f0;
    color: #334155;
}

.sip-btn-danger {
    background: #ef4444;
    color: white;
}

.sip-btn-danger:hover {
    background: #dc2626;
}

.sip-btn-small {
    padding: 4px 8px;
    font-size: 12px;
}

/* Forms */
.sip-input,
.sip-select {
    border: 1px solid #d1d5db;
    border-radius: 6px;
    padding: 8px 12px;
    font-size: 14px;
    transition: border-color 0.2s;
}

.sip-input:focus,
.sip-select:focus {
    outline: none;
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

.sip-form-group {
    margin-bottom: 20px;
}

.sip-form-group label {
    display: block;
    margin-bottom: 6px;
    font-weight: 500;
    color: #374151;
}

/* Tables */
.sip-table-container {
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    overflow: hidden;
    margin-bottom: 20px;
}

.sip-table {
    width: 100%;
    border-collapse: collapse;
}

.sip-table th {
    background: #f8fafc;
    padding: 12px;
    text-align: left;
    font-weight: 600;
    color: #374151;
    border-bottom: 1px solid #e2e8f0;
}

.sip-table td {
    padding: 12px;
    border-bottom: 1px solid #f1f5f9;
}

.sip-table tr:last-child td {
    border-bottom: none;
}

.sip-table tr:hover {
    background: #f8fafc;
}

/* Status Indicators */
.sip-status {
    display: inline-block;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 500;
    text-transform: uppercase;
}

.sip-status-success {
    background: #dcfce7;
    color: #166534;
}

.sip-status-warning {
    background: #fef3c7;
    color: #92400e;
}

.sip-status-error {
    background: #fee2e2;
    color: #991b1b;
}

/* Progress Bar */
.sip-usage-indicator {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 12px;
}

.sip-progress-bar {
    width: 60px;
    height: 6px;
    background: #e2e8f0;
    border-radius: 3px;
    overflow: hidden;
}

.sip-progress-fill {
    height: 100%;
    background: #3b82f6;
    transition: width 0.3s;
}

/* Filters */
.sip-filters {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
    align-items: center;
    flex-wrap: wrap;
}

/* Queue Stats */
.sip-queue-stats {
    display: flex;
    gap: 20px;
    margin-bottom: 20px;
    flex-wrap: wrap;
}

.sip-stat-card {
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 16px;
    text-align: center;
    min-width: 120px;
}

.sip-stat-number {
    font-size: 24px;
    font-weight: 700;
    color: #1e293b;
    margin-bottom: 4px;
}

.sip-stat-label {
    font-size: 12px;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

/* File Upload */
.sip-file-upload {
    display: flex;
    align-items: center;
    gap: 10px;
}

.sip-help-text {
    font-size: 12px;
    color: #64748b;
    margin-top: 4px;
}

/* Info Box */
.sip-info-box {
    background: #eff6ff;
    border: 1px solid #bfdbfe;
    border-radius: 8px;
    padding: 16px;
    margin-bottom: 20px;
}

.sip-info-box h3 {
    margin: 0 0 8px 0;
    color: #1e40af;
}

.sip-info-box p {
    margin: 0;
    color: #1e40af;
}

/* URL Links */
.sip-url-link {
    color: #3b82f6;
    text-decoration: none;
    word-break: break-all;
}

.sip-url-link:hover {
    text-decoration: underline;
}

.sip-url-title {
    font-weight: 500;
    color: #1e293b;
    margin-bottom: 4px;
}

.sip-queue-title {
    font-weight: 500;
    color: #1e293b;
    margin-bottom: 4px;
}

.sip-queue-meta {
    font-size: 12px;
    color: #64748b;
}

/* No Data */
.sip-no-data {
    text-align: center;
    color: #64748b;
    font-style: italic;
    padding: 40px 20px !important;
}

/* Sections */
.sip-section {
    margin-bottom: 30px;
}

.sip-section h2 {
    font-size: 18px;
    font-weight: 600;
    color: #1e293b;
    margin-bottom: 16px;
}

.sip-table-footer {
    padding: 16px;
    background: #f8fafc;
    border-top: 1px solid #e2e8f0;
    text-align: center;
}

.sip-link {
    color: #3b82f6;
    text-decoration: none;
    font-weight: 500;
}

.sip-link:hover {
    text-decoration: underline;
}

/* Responsive */
@media (max-width: 768px) {
    .sip-dashboard-grid {
        grid-template-columns: 1fr;
    }
    
    .sip-queue-stats {
        justify-content: center;
    }
    
    .sip-filters {
        flex-direction: column;
        align-items: stretch;
    }
    
    .sip-quick-actions {
        flex-direction: column;
    }
    
    .sip-input-group {
        flex-direction: column;
    }
}</style>
<div class="wrap sip-dashboard">
    <h1 class="sip-page-title">
        <span class="dashicons dashicons-search"></span>
        Smart Indexing Pro Dashboard
    </h1>
    
    <div class="sip-dashboard-grid">
        <!-- Indexing Performance Card -->
        <div class="sip-card">
            <div class="sip-card-header">
                <h2><span class="dashicons dashicons-chart-line"></span> Indexing Performance</h2>
                <div class="sip-card-subtitle">Google Indexing Success Rate</div>
            </div>
            <div class="sip-card-content">
                <div class="sip-metric-large"><?php echo $google_indexing_rate; ?>%</div>
                <div class="sip-metric-details">
                    <div><span>Total URLs Processed</span><strong><?php echo number_format($queue_stats['total']); ?></strong></div>
                    <div><span>Successfully Indexed</span><strong><?php echo number_format($queue_stats['completed']); ?></strong></div>
                    <div><span>Currently Pending</span><strong><?php echo number_format($queue_stats['pending']); ?></strong></div>
                    <div><span>Failed Attempts</span><strong><?php echo number_format($queue_stats['failed']); ?></strong></div>
                </div>
            </div>
        </div>
        
        <!-- API Usage Card -->
        <div class="sip-card">
            <div class="sip-card-header">
                <h2><span class="dashicons dashicons-admin-network"></span> API Usage Status</h2>
                <div class="sip-card-subtitle"><?php echo number_format($total_usage); ?> of <?php echo number_format($total_keys * 200); ?> daily requests used</div>
            </div>
            <div class="sip-card-content">
                <div class="sip-metric-large"><?php echo $api_usage_percentage; ?>%</div>
                <div class="sip-progress">
                    <div class="sip-progress-bar" style="width: <?php echo min($api_usage_percentage, 100); ?>%"></div>
                </div>
                <div class="sip-metric-details">
                    <div><span>Active API Keys</span><strong><?php echo number_format($total_keys); ?></strong></div>
                    <div><span>Daily Request Limit</span><strong><?php echo number_format($total_keys * 200); ?></strong></div>
                    <div><span>Quota Reset Time</span><strong>Daily at 00:00 UTC</strong></div>
                    <div><span>Recent Activity (24h)</span><strong><?php echo number_format($log_stats['recent_activity']); ?></strong></div>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions Card -->
        <div class="sip-card">
            <div class="sip-card-header">
                <h2><span class="dashicons dashicons-admin-tools"></span> Quick Actions</h2>
                <div class="sip-card-subtitle">Manage your indexing workflow efficiently</div>
            </div>
            <div class="sip-card-content">
                <div class="sip-quick-actions">
                    <a href="<?php echo admin_url('admin.php?page=sip-queue'); ?>" class="sip-btn sip-btn-primary">
                        <span class="dashicons dashicons-list-view"></span> View URL Queue
                    </a>
                    <a href="<?php echo admin_url('admin.php?page=sip-api-keys'); ?>" class="sip-btn sip-btn-secondary">
                        <span class="dashicons dashicons-admin-network"></span> Manage API Keys
                    </a>
                    <a href="<?php echo admin_url('admin.php?page=sip-settings'); ?>" class="sip-btn sip-btn-secondary">
                        <span class="dashicons dashicons-admin-settings"></span> Plugin Settings
                    </a>
                </div>
                
                <div class="sip-manual-submit">
                    <label for="manual-url">
                        <span class="dashicons dashicons-admin-links"></span> 
                        Submit URL for Indexing
                    </label>
                    <div class="sip-input-group">
                        <input 
                            type="url" 
                            id="manual-url" 
                            placeholder="https://example.com/your-page" 
                            class="sip-input"
                        >
                        <button type="button" id="submit-manual-url" class="sip-btn sip-btn-primary">
                            <span class="dashicons dashicons-upload"></span> Submit URL
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Recent Activity Section -->
    <div class="sip-section">
        <h2><span class="dashicons dashicons-clock"></span> Recent Indexing Activity</h2>
        <div class="sip-table-container">
            <table class="sip-table">
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>URL</th>
                        <th>API Key Used</th>
                        <th>Action</th>
                        <th>Status</th>
                        <th>Message</th>
                    </tr>
                </thead>
                <tbody id="recent-activity-table">
                    <?php
                    $recent_logs = $logger->get_recent_logs(10);
                    if ($recent_logs && count($recent_logs) > 0) {
                        foreach ($recent_logs as $log) {
                            $status_class = $log->status === 'success' ? 'sip-status-success' : 'sip-status-error';
                            echo '<tr>';
                            echo '<td>' . date('M j, Y H:i:s', strtotime($log->created_at)) . '</td>';
                            echo '<td>';
                            echo '<div class="sip-url-title">' . esc_html(wp_trim_words($log->url, 6, '...')) . '</div>';
                            echo '<div class="sip-url-link"><a href="' . esc_url($log->url) . '" target="_blank">' . esc_html($log->url) . '</a></div>';
                            echo '</td>';
                            echo '<td>' . esc_html($log->api_key_name ? $log->api_key_name : 'System') . '</td>';
                            echo '<td><span class="sip-status sip-status-pending">' . esc_html(ucfirst($log->action)) . '</span></td>';
                            echo '<td><span class="sip-status ' . $status_class . '">' . esc_html(ucfirst($log->status)) . '</span></td>';
                            echo '<td>' . esc_html($log->message) . '</td>';
                            echo '</tr>';
                        }
                    } else {
                        echo '<tr><td colspan="6" class="sip-no-data">No recent activity found. Submit your first URL above to get started!</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- URL Queue Status Section -->
    <div class="sip-section">
        <h2><span class="dashicons dashicons-update"></span> URL Queue Overview</h2>
        <div class="sip-table-container">
            <table class="sip-table">
                <thead>
                    <tr>
                        <th>URL Information</th>
                        <th>Queue Status</th>
                        <th>Retry Count</th>
                        <th>Last Attempt</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $recent_queue = $queue_manager->get_queue_items(10);
                    if ($recent_queue && count($recent_queue) > 0) {
                        foreach ($recent_queue as $item) {
                            echo '<tr>';
                            echo '<td>';
                            if ($item->post_title) {
                                echo '<div class="sip-url-title">' . esc_html($item->post_title) . '</div>';
                            }
                            echo '<div class="sip-url-link"><a href="' . esc_url($item->url) . '" target="_blank">' . esc_html($item->url) . '</a></div>';
                            echo '</td>';
                            
                            $status_class = '';
                            $status_text = ucfirst($item->status);
                            if ($item->status === 'completed') {
                                $status_class = 'sip-status-success';
                                $status_text = 'Completed';
                            } elseif ($item->status === 'failed') {
                                $status_class = 'sip-status-error';
                                $status_text = 'Failed';
                            } elseif ($item->status === 'pending') {
                                $status_class = 'sip-status-pending';
                                $status_text = 'Pending';
                            } elseif ($item->status === 'processing') {
                                $status_class = 'sip-status-pending';
                                $status_text = 'Processing';
                            }
                            
                            echo '<td><span class="sip-status ' . $status_class . '">' . $status_text . '</span></td>';
                            echo '<td><span class="sip-status sip-status-pending">' . intval($item->retry_count) . ' / 10</span></td>';
                            echo '<td>' . ($item->last_attempt ? date('M j, H:i', strtotime($item->last_attempt)) : 'Never') . '</td>';
                            echo '<td>';
                            echo '<button class="sip-btn sip-btn-small sip-btn-primary recheck-url" data-url="' . esc_attr($item->url) . '" title="Resubmit this URL for indexing">';
                            echo '<span class="dashicons dashicons-update"></span> Recheck';
                            echo '</button> ';
                            echo '<button class="sip-btn sip-btn-small sip-btn-danger remove-url" data-url="' . esc_attr($item->url) . '" title="Remove this URL from queue">';
                            echo '<span class="dashicons dashicons-trash"></span> Remove';
                            echo '</button>';
                            echo '</td>';
                            echo '</tr>';
                        }
                    } else {
                        echo '<tr><td colspan="5" class="sip-no-data">No URLs in queue yet. Submit some URLs above to begin indexing!</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <div class="sip-table-footer">
            <a href="<?php echo admin_url('admin.php?page=sip-queue'); ?>" class="sip-link">
                View complete URL queue <span class="dashicons dashicons-arrow-right-alt"></span>
            </a>
        </div>
    </div>
</div>

