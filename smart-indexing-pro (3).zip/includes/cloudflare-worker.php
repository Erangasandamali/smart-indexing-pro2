<?php
if (!defined('ABSPATH')) {
    exit;
}

class SIP_Cloudflare_Worker {
    
    private $worker_url;
    private $auth_token;
    
    public function __construct() {
        $settings = get_option('sip_settings', array());
        $this->worker_url = isset($settings['cloudflare_worker_url']) ? $settings['cloudflare_worker_url'] : '';
        $this->auth_token = isset($settings['cloudflare_auth_token']) ? $settings['cloudflare_auth_token'] : '';
        
        add_action('sip_process_remote_queue', array($this, 'process_remote_queue'));
    }
    
    public function is_enabled() {
        return !empty($this->worker_url) && !empty($this->auth_token);
    }
    
    public function send_to_worker($urls) {
        if (!$this->is_enabled()) {
            return false;
        }
        
        $payload = array(
            'urls' => $urls,
            'site_url' => get_site_url(),
            'timestamp' => time()
        );
        
        $response = wp_remote_post($this->worker_url, array(
            'body' => json_encode($payload),
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $this->auth_token,
                'X-Site-Token' => wp_create_nonce('sip_cloudflare_' . get_site_url())
            ),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            error_log('SIP Cloudflare Worker Error: ' . $response->get_error_message());
            return false;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        return isset($data['success']) && $data['success'];
    }
    
    public function process_remote_queue() {
        if (!$this->is_enabled()) {
            return;
        }
        
        global $wpdb;
        
        // Get pending URLs to send to worker
        $pending_urls = $wpdb->get_results(
            "SELECT id, url FROM {$wpdb->prefix}sip_queue 
             WHERE status = 'pending' 
             ORDER BY created_at ASC 
             LIMIT 50"
        );
        
        if (empty($pending_urls)) {
            return;
        }
        
        $urls_to_send = array();
        $queue_ids = array();
        
        foreach ($pending_urls as $item) {
            $urls_to_send[] = $item->url;
            $queue_ids[] = $item->id;
        }
        
        // Mark as processing
        $wpdb->query(sprintf(
            "UPDATE {$wpdb->prefix}sip_queue SET status = 'processing' WHERE id IN (%s)",
            implode(',', array_map('intval', $queue_ids))
        ));
        
        // Send to Cloudflare Worker
        $success = $this->send_to_worker($urls_to_send);
        
        if ($success) {
            // Mark as completed
            $wpdb->query(sprintf(
                "UPDATE {$wpdb->prefix}sip_queue SET status = 'completed' WHERE id IN (%s)",
                implode(',', array_map('intval', $queue_ids))
            ));
            
            // Log success
            $logger = new SIP_Logger();
            foreach ($urls_to_send as $url) {
                $logger->log($url, null, 'cloudflare_submit', 'success', 'Sent to Cloudflare Worker');
            }
        } else {
            // Mark as failed
            $wpdb->query(sprintf(
                "UPDATE {$wpdb->prefix}sip_queue SET status = 'failed' WHERE id IN (%s)",
                implode(',', array_map('intval', $queue_ids))
            ));
            
            // Log failure
            $logger = new SIP_Logger();
            foreach ($urls_to_send as $url) {
                $logger->log($url, null, 'cloudflare_submit', 'error', 'Failed to send to Cloudflare Worker');
            }
        }
    }
    
    public function get_worker_template() {
        return '
// Cloudflare Worker Template for Smart Indexing Pro
addEventListener("fetch", event => {
  event.respondWith(handleRequest(event.request))
})

async function handleRequest(request) {
  if (request.method !== "POST") {
    return new Response("Method not allowed", { status: 405 })
  }
  
  const authHeader = request.headers.get("Authorization")
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return new Response("Unauthorized", { status: 401 })
  }
  
  try {
    const data = await request.json()
    const { urls, site_url } = data
    
    // Process URLs with Google Indexing API
    const results = await Promise.all(
      urls.map(url => submitToGoogle(url))
    )
    
    return new Response(JSON.stringify({
      success: true,
      processed: results.length,
      results: results
    }), {
      headers: { "Content-Type": "application/json" }
    })
  } catch (error) {
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    })
  }
}

async function submitToGoogle(url) {
  // Your Google Indexing API logic here
  // This is just a template - implement actual submission logic
  return { url, status: "submitted" }
}
';
    }
}