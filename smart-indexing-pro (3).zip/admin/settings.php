<?php
if (!defined('ABSPATH')) {
    exit;
}

// Handle form submission
if (isset($_POST['save_settings']) && wp_verify_nonce($_POST['_wpnonce'], 'sip_settings')) {
    $settings = array(
        'auto_submit_on_publish' => isset($_POST['auto_submit_on_publish']) ? 1 : 0,
        'retry_frequency' => intval($_POST['retry_frequency']),
        'max_retry_attempts' => intval($_POST['max_retry_attempts']),
        'enable_bing' => isset($_POST['enable_bing']) ? 1 : 0,
        'enable_yandex' => isset($_POST['enable_yandex']) ? 1 : 0,
        'post_types' => isset($_POST['post_types']) ? $_POST['post_types'] : array(),
        'email_notifications' => isset($_POST['email_notifications']) ? 1 : 0,
        'notification_email' => sanitize_email($_POST['notification_email'])
    );
    
    update_option('sip_settings', $settings);
    echo '<div class="notice notice-success"><p>Settings saved successfully!</p></div>';
}

$settings = get_option('sip_settings', array());
$post_types = get_post_types(array('public' => true), 'objects');
?>
<style>/* Smart Indexing Pro Admin Styles */
.sip-dashboard,
.sip-api-keys,
.sip-queue,
.sip-logs,
.sip-settings {
    margin: 20px 0;
}

.sip-page-title {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 24px;
    font-weight: 600;
    margin-bottom: 20px;
    color: #1e293b;
}

.sip-page-title .dashicons {
    color: #3b82f6;
}

/* Dashboard Grid */
.sip-dashboard-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

/* Cards */
.sip-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    overflow: hidden;
}

.sip-card-header {
    padding: 16px 20px;
    border-bottom: 1px solid #e2e8f0;
    background: #f8fafc;
}

.sip-card-header h2 {
    margin: 0;
    font-size: 16px;
    font-weight: 600;
    color: #1e293b;
}

.sip-card-subtitle {
    font-size: 12px;
    color: #64748b;
    margin-top: 4px;
    display: block;
}

.sip-card-content {
    padding: 20px;
}

/* Metrics */
.sip-metric-large {
    font-size: 36px;
    font-weight: 700;
    color: #1e293b;
    margin-bottom: 10px;
}

.sip-metric-details {
    font-size: 13px;
    color: #64748b;
    line-height: 1.4;
}

.sip-metric-details div {
    margin-bottom: 2px;
}

/* Quick Actions */
.sip-quick-actions {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
    flex-wrap: wrap;
}

.sip-manual-submit {
    margin-top: 20px;
}

.sip-manual-submit label {
    display: block;
    margin-bottom: 8px;
    font-weight: 500;
    color: #374151;
}

.sip-input-group {
    display: flex;
    gap: 10px;
}

.sip-input-group .sip-input {
    flex: 1;
}

/* Buttons */
.sip-btn {
    display: inline-block;
    padding: 8px 16px;
    border: none;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.2s;
    line-height: 1.4;
}

.sip-btn-primary {
    background: #3b82f6;
    color: white;
}

.sip-btn-primary:hover {
    background: #2563eb;
    color: white;
}

.sip-btn-secondary {
    background: #f1f5f9;
    color: #475569;
    border: 1px solid #e2e8f0;
}

.sip-btn-secondary:hover {
    background: #e2e8f0;
    color: #334155;
}

.sip-btn-danger {
    background: #ef4444;
    color: white;
}

.sip-btn-danger:hover {
    background: #dc2626;
}

.sip-btn-small {
    padding: 4px 8px;
    font-size: 12px;
}

/* Forms */
.sip-input,
.sip-select {
    border: 1px solid #d1d5db;
    border-radius: 6px;
    padding: 8px 12px;
    font-size: 14px;
    transition: border-color 0.2s;
}

.sip-input:focus,
.sip-select:focus {
    outline: none;
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

.sip-form-group {
    margin-bottom: 20px;
}

.sip-form-group label {
    display: block;
    margin-bottom: 6px;
    font-weight: 500;
    color: #374151;
}

/* Tables */
.sip-table-container {
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    overflow: hidden;
    margin-bottom: 20px;
}

.sip-table {
    width: 100%;
    border-collapse: collapse;
}

.sip-table th {
    background: #f8fafc;
    padding: 12px;
    text-align: left;
    font-weight: 600;
    color: #374151;
    border-bottom: 1px solid #e2e8f0;
}

.sip-table td {
    padding: 12px;
    border-bottom: 1px solid #f1f5f9;
}

.sip-table tr:last-child td {
    border-bottom: none;
}

.sip-table tr:hover {
    background: #f8fafc;
}

/* Status Indicators */
.sip-status {
    display: inline-block;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 500;
    text-transform: uppercase;
}

.sip-status-success {
    background: #dcfce7;
    color: #166534;
}

.sip-status-warning {
    background: #fef3c7;
    color: #92400e;
}

.sip-status-error {
    background: #fee2e2;
    color: #991b1b;
}

/* Progress Bar */
.sip-usage-indicator {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 12px;
}

.sip-progress-bar {
    width: 60px;
    height: 6px;
    background: #e2e8f0;
    border-radius: 3px;
    overflow: hidden;
}

.sip-progress-fill {
    height: 100%;
    background: #3b82f6;
    transition: width 0.3s;
}

/* Filters */
.sip-filters {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
    align-items: center;
    flex-wrap: wrap;
}

/* Queue Stats */
.sip-queue-stats {
    display: flex;
    gap: 20px;
    margin-bottom: 20px;
    flex-wrap: wrap;
}

.sip-stat-card {
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 16px;
    text-align: center;
    min-width: 120px;
}

.sip-stat-number {
    font-size: 24px;
    font-weight: 700;
    color: #1e293b;
    margin-bottom: 4px;
}

.sip-stat-label {
    font-size: 12px;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

/* File Upload */
.sip-file-upload {
    display: flex;
    align-items: center;
    gap: 10px;
}

.sip-help-text {
    font-size: 12px;
    color: #64748b;
    margin-top: 4px;
}

/* Info Box */
.sip-info-box {
    background: #eff6ff;
    border: 1px solid #bfdbfe;
    border-radius: 8px;
    padding: 16px;
    margin-bottom: 20px;
}

.sip-info-box h3 {
    margin: 0 0 8px 0;
    color: #1e40af;
}

.sip-info-box p {
    margin: 0;
    color: #1e40af;
}

/* URL Links */
.sip-url-link {
    color: #3b82f6;
    text-decoration: none;
    word-break: break-all;
}

.sip-url-link:hover {
    text-decoration: underline;
}

.sip-url-title {
    font-weight: 500;
    color: #1e293b;
    margin-bottom: 4px;
}

.sip-queue-title {
    font-weight: 500;
    color: #1e293b;
    margin-bottom: 4px;
}

.sip-queue-meta {
    font-size: 12px;
    color: #64748b;
}

/* No Data */
.sip-no-data {
    text-align: center;
    color: #64748b;
    font-style: italic;
    padding: 40px 20px !important;
}

/* Sections */
.sip-section {
    margin-bottom: 30px;
}

.sip-section h2 {
    font-size: 18px;
    font-weight: 600;
    color: #1e293b;
    margin-bottom: 16px;
}

.sip-table-footer {
    padding: 16px;
    background: #f8fafc;
    border-top: 1px solid #e2e8f0;
    text-align: center;
}

.sip-link {
    color: #3b82f6;
    text-decoration: none;
    font-weight: 500;
}

.sip-link:hover {
    text-decoration: underline;
}

/* Responsive */
@media (max-width: 768px) {
    .sip-dashboard-grid {
        grid-template-columns: 1fr;
    }
    
    .sip-queue-stats {
        justify-content: center;
    }
    
    .sip-filters {
        flex-direction: column;
        align-items: stretch;
    }
    
    .sip-quick-actions {
        flex-direction: column;
    }
    
    .sip-input-group {
        flex-direction: column;
    }
}</style>
<div class="wrap sip-settings">
    <h1 class="sip-page-title">
        <span class="dashicons dashicons-admin-settings"></span>
        Smart Indexing Pro Settings
    </h1>
    
    <form method="post" action="">
        <?php wp_nonce_field('sip_settings'); ?>
        
        <div class="sip-card">
            <div class="sip-card-header">
                <h2>General Settings</h2>
                <p>Configure the general behavior of Smart Indexing Pro.</p>
            </div>
            <div class="sip-card-content">
                <table class="form-table">
                    <tr>
                        <th scope="row">Auto-Submit on Publish</th>
                        <td>
                            <label>
                                <input type="checkbox" name="auto_submit_on_publish" value="1" <?php checked(isset($settings['auto_submit_on_publish']) ? $settings['auto_submit_on_publish'] : 1); ?>>
                                Automatically submit new and updated published content for indexing
                            </label>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Post Types to Index</th>
                        <td>
                            <fieldset>
                                <?php foreach ($post_types as $post_type): ?>
                                    <label>
                                        <input type="checkbox" name="post_types[]" value="<?php echo esc_attr($post_type->name); ?>" 
                                               <?php checked(in_array($post_type->name, isset($settings['post_types']) ? $settings['post_types'] : array('post', 'page'))); ?>>
                                        <?php echo esc_html($post_type->label); ?>
                                    </label><br>
                                <?php endforeach; ?>
                                <p class="description">Select which post types to automatically submit for indexing</p>
                            </fieldset>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Retry Frequency (hours)</th>
                        <td>
                            <select name="retry_frequency">
                                <option value="6" <?php selected(isset($settings['retry_frequency']) ? $settings['retry_frequency'] : 6, 6); ?>>Every 6 hours</option>
                                <option value="12" <?php selected(isset($settings['retry_frequency']) ? $settings['retry_frequency'] : 6, 12); ?>>Every 12 hours</option>
                                <option value="24" <?php selected(isset($settings['retry_frequency']) ? $settings['retry_frequency'] : 6, 24); ?>>Every 24 hours</option>
                            </select>
                            <p class="description">How often to retry checking unindexed URLs</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Maximum Retry Attempts</th>
                        <td>
                            <input type="number" name="max_retry_attempts" value="<?php echo esc_attr(isset($settings['max_retry_attempts']) ? $settings['max_retry_attempts'] : 10); ?>" min="1" max="50" class="small-text">
                            <p class="description">How many times to retry checking a URL before giving up</p>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        
        <div class="sip-card">
            <div class="sip-card-header">
                <h2>Search Engine Settings</h2>
                <p>Configure additional search engines beyond Google.</p>
            </div>
            <div class="sip-card-content">
                <table class="form-table">
                    <tr>
                        <th scope="row">Bing Indexing</th>
                        <td>
                            <label>
                                <input type="checkbox" name="enable_bing" value="1" <?php checked(isset($settings['enable_bing']) ? $settings['enable_bing'] : 0); ?>>
                                Enable Bing indexing status checks and submission
                            </label>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Yandex Indexing</th>
                        <td>
                            <label>
                                <input type="checkbox" name="enable_yandex" value="1" <?php checked(isset($settings['enable_yandex']) ? $settings['enable_yandex'] : 0); ?>>
                                Enable Yandex indexing status checks and submission
                            </label>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        
        <div class="sip-card">
            <div class="sip-card-header">
                <h2>Notification Settings</h2>
                <p>Configure email notifications and reports.</p>
            </div>
            <div class="sip-card-content">
                <table class="form-table">
                    <tr>
                        <th scope="row">Email Reports</th>
                        <td>
                            <label>
                                <input type="checkbox" name="email_notifications" value="1" <?php checked(isset($settings['email_notifications']) ? $settings['email_notifications'] : 0); ?>>
                                Send weekly indexing reports via email
                            </label>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Notification Email</th>
                        <td>
                            <input type="email" name="notification_email" value="<?php echo esc_attr(isset($settings['notification_email']) ? $settings['notification_email'] : get_option('admin_email')); ?>" class="regular-text">
                            <p class="description">Email address for notifications and reports</p>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        
        <p class="submit">
            <input type="submit" name="save_settings" id="submit" class="button-primary" value="Save Changes">
        </p>
    </form>
</div>