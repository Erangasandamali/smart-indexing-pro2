<?php
if (!defined('ABSPATH')) {
    exit;
}

class SIP_API_Manager {
    
    private $table_name;
    
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'sip_api_keys';
    }
    
    public function upload_api_key($name, $json_content) {
        global $wpdb;
        
        // Validate JSON
        $decoded = json_decode($json_content, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return array('success' => false, 'message' => 'Invalid JSON format: ' . json_last_error_msg());
        }
        
        // Check if required fields exist
        if (!isset($decoded['client_email']) || !isset($decoded['private_key'])) {
            return array('success' => false, 'message' => 'Invalid service account JSON. Missing client_email or private_key.');
        }
        
        // Additional validation
        if (!isset($decoded['type']) || $decoded['type'] !== 'service_account') {
            return array('success' => false, 'message' => 'Invalid service account JSON. Type must be "service_account".');
        }
        
        // Check if key name already exists
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->table_name} WHERE name = %s",
            $name
        ));
        
        if ($existing > 0) {
            return array('success' => false, 'message' => 'A key with this name already exists.');
        }
        
        // Encrypt the JSON content for security
        $encrypted_json = $this->encrypt_json($json_content);
        
        $result = $wpdb->insert(
            $this->table_name,
            array(
                'name' => sanitize_text_field($name),
                'json_content' => $encrypted_json,
                'usage_today' => 0,
                'status' => 'active',
                'created_at' => current_time('mysql')
            ),
            array('%s', '%s', '%d', '%s', '%s')
        );
        
        if ($result) {
            return array('success' => true, 'message' => 'API key uploaded successfully');
        } else {
            return array('success' => false, 'message' => 'Failed to save API key: ' . $wpdb->last_error);
        }
    }
    
    public function get_api_keys() {
        global $wpdb;
        
        $keys = $wpdb->get_results("SELECT id, name, usage_today, last_used, status, created_at FROM {$this->table_name} ORDER BY created_at DESC");
        
        return $keys;
    }
    
    public function get_available_api_key() {
        global $wpdb;
        
        // Get key with lowest usage that hasn't exceeded quota
        $key = $wpdb->get_row("SELECT * FROM {$this->table_name} WHERE status = 'active' AND usage_today < 200 ORDER BY usage_today ASC LIMIT 1");
        
        if ($key) {
            $key->json_content = $this->decrypt_json($key->json_content);
            return $key;
        }
        
        return null;
    }
    
    public function increment_usage($api_key_id) {
        global $wpdb;
        
        $wpdb->query($wpdb->prepare(
            "UPDATE {$this->table_name} SET usage_today = usage_today + 1, last_used = NOW() WHERE id = %d",
            $api_key_id
        ));
        
        // Check if quota exceeded
        $usage = $wpdb->get_var($wpdb->prepare(
            "SELECT usage_today FROM {$this->table_name} WHERE id = %d",
            $api_key_id
        ));
        
        if ($usage >= 200) {
            $wpdb->update(
                $this->table_name,
                array('status' => 'quota_exceeded'),
                array('id' => $api_key_id),
                array('%s'),
                array('%d')
            );
        }
    }
    
    public function reset_daily_quotas() {
        global $wpdb;
        
        $wpdb->query("UPDATE {$this->table_name} SET usage_today = 0, status = 'active' WHERE status = 'quota_exceeded'");
    }
    
    public function delete_api_key($key_id) {
        global $wpdb;
        
        $result = $wpdb->delete($this->table_name, array('id' => $key_id), array('%d'));
        
        if ($result) {
            return array('success' => true, 'message' => 'API key deleted successfully');
        } else {
            return array('success' => false, 'message' => 'Failed to delete API key: ' . $wpdb->last_error);
        }
    }
    
    public function get_total_usage_today() {
        global $wpdb;
        
        $usage = $wpdb->get_var("SELECT SUM(usage_today) FROM {$this->table_name}");
        return $usage ? intval($usage) : 0;
    }
    
    public function get_total_keys() {
        global $wpdb;
        
        $count = $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name}");
        return $count ? intval($count) : 0;
    }
    
    private function encrypt_json($json) {
        // Simple encryption - in production, use stronger encryption
        return base64_encode($json);
    }
    
    private function decrypt_json($encrypted_json) {
        return base64_decode($encrypted_json);
    }
}