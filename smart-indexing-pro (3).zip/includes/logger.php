<?php
if (!defined('ABSPATH')) {
    exit;
}

class SIP_Logger {
    
    private $table_name;
    
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'sip_logs';
    }
    
    public function log($url, $api_key_id, $action, $status, $message) {
        global $wpdb;
        
        $wpdb->insert(
            $this->table_name,
            array(
                'url' => esc_url_raw($url),
                'api_key_id' => $api_key_id,
                'action' => sanitize_text_field($action),
                'status' => sanitize_text_field($status),
                'message' => sanitize_text_field($message),
                'created_at' => current_time('mysql')
            ),
            array('%s', '%d', '%s', '%s', '%s', '%s')
        );
    }
    
    public function get_recent_logs($limit = 100, $offset = 0) {
        global $wpdb;
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT l.*, k.name as api_key_name 
             FROM {$this->table_name} l 
             LEFT JOIN {$wpdb->prefix}sip_api_keys k ON l.api_key_id = k.id 
             ORDER BY l.created_at DESC 
             LIMIT %d OFFSET %d",
            $limit, $offset
        ));
        
        return $results;
    }
    
    public function get_filtered_logs($status_filter = '', $action_filter = '', $url_search = '', $limit = 100) {
        global $wpdb;
        
        $where_clauses = array();
        $params = array();
        
        if (!empty($status_filter)) {
            $where_clauses[] = "l.status = %s";
            $params[] = $status_filter;
        }
        
        if (!empty($action_filter)) {
            $where_clauses[] = "l.action = %s";
            $params[] = $action_filter;
        }
        
        if (!empty($url_search)) {
            $where_clauses[] = "l.url LIKE %s";
            $params[] = '%' . $wpdb->esc_like($url_search) . '%';
        }
        
        $where_sql = '';
        if (!empty($where_clauses)) {
            $where_sql = 'WHERE ' . implode(' AND ', $where_clauses);
        }
        
        $params[] = $limit;
        
        $sql = "SELECT l.*, k.name as api_key_name 
                FROM {$this->table_name} l 
                LEFT JOIN {$wpdb->prefix}sip_api_keys k ON l.api_key_id = k.id 
                {$where_sql}
                ORDER BY l.created_at DESC 
                LIMIT %d";
        
        return $wpdb->get_results($wpdb->prepare($sql, $params));
    }
    
    public function get_logs_by_url($url, $limit = 20) {
        global $wpdb;
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT l.*, k.name as api_key_name 
             FROM {$this->table_name} l 
             LEFT JOIN {$wpdb->prefix}sip_api_keys k ON l.api_key_id = k.id 
             WHERE l.url = %s 
             ORDER BY l.created_at DESC 
             LIMIT %d",
            $url, $limit
        ));
        
        return $results;
    }
    
    public function clean_old_logs($days = 30) {
        global $wpdb;
        
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$this->table_name} WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ));
    }
    
    public function get_log_stats() {
        global $wpdb;
        
        $stats = array(
            'total_logs' => $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name}"),
            'successful_submissions' => $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name} WHERE action = 'submit' AND status = 'success'"),
            'failed_submissions' => $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name} WHERE action = 'submit' AND status = 'error'"),
            'recent_activity' => $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name} WHERE created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)")
        );
        
        return $stats;
    }
}