<?php
if (!defined('ABSPATH')) {
    exit;
}

$queue_manager = new SIP_Queue_Manager();
$queue_items = $queue_manager->get_queue_items(50);
$queue_stats = $queue_manager->get_queue_stats();

// Handle filter requests
$status_filter = isset($_GET['status_filter']) ? sanitize_text_field($_GET['status_filter']) : '';
$post_type_filter = isset($_GET['post_type_filter']) ? sanitize_text_field($_GET['post_type_filter']) : '';
$url_search = isset($_GET['url_search']) ? sanitize_text_field($_GET['url_search']) : '';

if ($status_filter || $post_type_filter || $url_search) {
    $queue_items = $queue_manager->get_filtered_queue_items($status_filter, $post_type_filter, $url_search, 50);
}
?>

<div class="wrap">
    <div class="sip-dashboard">
        <h1 class="sip-page-title">
            <span class="dashicons dashicons-list-view"></span>
            URL Indexing Queue
        </h1>
        
        <div class="sip-card">
            <div class="sip-card-header">
                <h2><span class="dashicons dashicons-filter"></span> Filters</h2>
            </div>
            <div class="sip-card-content">
                <form method="get" class="sip-filters">
                    <input type="hidden" name="page" value="sip-queue">
                    
                    <div class="sip-filter-row">
                        <select name="status_filter" class="sip-select">
                            <option value="">All Statuses</option>
                            <option value="pending" <?php selected($status_filter, 'pending'); ?>>Pending</option>
                            <option value="processing" <?php selected($status_filter, 'processing'); ?>>Processing</option>
                            <option value="completed" <?php selected($status_filter, 'completed'); ?>>Completed</option>
                            <option value="failed" <?php selected($status_filter, 'failed'); ?>>Failed</option>
                        </select>
                        
                        <select name="post_type_filter" class="sip-select">
                            <option value="">All Post Types</option>
                            <option value="post" <?php selected($post_type_filter, 'post'); ?>>Posts</option>
                            <option value="page" <?php selected($post_type_filter, 'page'); ?>>Pages</option>
                        </select>
                        
                        <input type="text" name="url_search" value="<?php echo esc_attr($url_search); ?>" placeholder="Search URLs..." class="sip-input">
                        
                        <button type="submit" class="sip-btn sip-btn-primary">
                            <span class="dashicons dashicons-search"></span> Filter
                        </button>
                        
                        <a href="<?php echo admin_url('admin.php?page=sip-queue'); ?>" class="sip-btn sip-btn-secondary">
                            <span class="dashicons dashicons-dismiss"></span> Clear
                        </a>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="sip-queue-stats">
            <div class="sip-stat-card">
                <div class="sip-stat-number"><?php echo $queue_stats['total']; ?></div>
                <div class="sip-stat-label">Total URLs</div>
            </div>
            <div class="sip-stat-card">
                <div class="sip-stat-number"><?php echo $queue_stats['pending']; ?></div>
                <div class="sip-stat-label">Pending</div>
            </div>
            <div class="sip-stat-card">
                <div class="sip-stat-number"><?php echo $queue_stats['completed']; ?></div>
                <div class="sip-stat-label">Completed</div>
            </div>
            <div class="sip-stat-card">
                <div class="sip-stat-number"><?php echo $queue_stats['failed']; ?></div>
                <div class="sip-stat-label">Failed</div>
            </div>
        </div>
        
        <div class="sip-section">
            <h2><span class="dashicons dashicons-list-view"></span> Queue Items</h2>
            <div class="sip-table-container">
                <table class="sip-table">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>URL</th>
                            <th>Status</th>
                            <th>Last Checked</th>
                            <th>Retries</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($queue_items): ?>
                            <?php foreach ($queue_items as $item): ?>
                                <tr>
                                    <td>
                                        <div class="sip-queue-title">
                                            <?php 
                                            if ($item->post_title) {
                                                echo esc_html($item->post_title);
                                            } else {
                                                $url_parts = parse_url($item->url);
                                                echo esc_html(basename($url_parts['path']) ?: 'Untitled');
                                            }
                                            ?>
                                        </div>
                                        <?php if ($item->post_id): ?>
                                            <div class="sip-queue-meta">
                                                <a href="<?php echo get_edit_post_link($item->post_id); ?>" target="_blank">Edit Post</a>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo esc_url($item->url); ?>" target="_blank" class="sip-url-link">
                                            <?php echo esc_html(wp_trim_words($item->url, 8, '...')); ?>
                                        </a>
                                    </td>
                                    <td>
                                        <?php
                                        $status_class = '';
                                        $status_text = ucfirst($item->status);
                                        
                                        if ($item->status === 'completed') {
                                            $status_class = 'sip-status-success';
                                        } elseif ($item->status === 'failed') {
                                            $status_class = 'sip-status-error';
                                        } elseif ($item->status === 'processing') {
                                            $status_class = 'sip-status-warning';
                                        } else {
                                            $status_class = 'sip-status-pending';
                                        }
                                        ?>
                                        <span class="sip-status <?php echo $status_class; ?>"><?php echo $status_text; ?></span>
                                    </td>
                                    <td>
                                        <?php echo $item->last_attempt ? human_time_diff(strtotime($item->last_attempt)) . ' ago' : 'Never'; ?>
                                    </td>
                                    <td><?php echo $item->retry_count; ?></td>
                                    <td>
                                        <button class="sip-btn sip-btn-small sip-btn-secondary reindex-url" data-url="<?php echo esc_attr($item->url); ?>">
                                            <span class="dashicons dashicons-update"></span> Reindex
                                        </button>
                                        <button class="sip-btn sip-btn-small sip-btn-danger remove-url" data-url="<?php echo esc_attr($item->url); ?>">
                                            <span class="dashicons dashicons-trash"></span> Remove
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="sip-no-data">No URLs found in queue.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>