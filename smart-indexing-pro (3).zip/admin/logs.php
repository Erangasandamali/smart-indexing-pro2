<?php
if (!defined('ABSPATH')) {
    exit;
}

$logger = new SIP_Logger();

// Handle filter requests
$status_filter = isset($_GET['status_filter']) ? sanitize_text_field($_GET['status_filter']) : '';
$action_filter = isset($_GET['action_filter']) ? sanitize_text_field($_GET['action_filter']) : '';
$url_search = isset($_GET['url_search']) ? sanitize_text_field($_GET['url_search']) : '';

$logs = $logger->get_filtered_logs($status_filter, $action_filter, $url_search, 100);
?>

<div class="wrap">
    <div class="sip-dashboard">
        <h1 class="sip-page-title">
            <span class="dashicons dashicons-admin-generic"></span>
            Indexing Logs
        </h1>
        
        <div class="sip-card">
            <div class="sip-card-header">
                <h2><span class="dashicons dashicons-filter"></span> Filters</h2>
            </div>
            <div class="sip-card-content">
                <form method="get" class="sip-filters">
                    <input type="hidden" name="page" value="sip-logs">
                    
                    <div class="sip-filter-row">
                        <select name="status_filter" class="sip-select">
                            <option value="">All Statuses</option>
                            <option value="success" <?php selected($status_filter, 'success'); ?>>Success</option>
                            <option value="error" <?php selected($status_filter, 'error'); ?>>Error</option>
                        </select>
                        
                        <select name="action_filter" class="sip-select">
                            <option value="">All Actions</option>
                            <option value="submit" <?php selected($action_filter, 'submit'); ?>>Submit</option>
                            <option value="check" <?php selected($action_filter, 'check'); ?>>Check</option>
                        </select>
                        
                        <input type="text" name="url_search" value="<?php echo esc_attr($url_search); ?>" placeholder="Search URLs..." class="sip-input">
                        
                        <button type="submit" class="sip-btn sip-btn-primary">
                            <span class="dashicons dashicons-search"></span> Filter
                        </button>
                        
                        <a href="<?php echo admin_url('admin.php?page=sip-logs'); ?>" class="sip-btn sip-btn-secondary">
                            <span class="dashicons dashicons-dismiss"></span> Clear
                        </a>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="sip-section">
            <h2><span class="dashicons dashicons-clock"></span> Recent Activity</h2>
            <div class="sip-table-container">
                <table class="sip-table">
                    <thead>
                        <tr>
                            <th>Time</th>
                            <th>URL</th>
                            <th>API Key</th>
                            <th>Action</th>
                            <th>Status</th>
                            <th>Message</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($logs): ?>
                            <?php foreach ($logs as $log): ?>
                                <tr>
                                    <td><?php echo date('M j, Y H:i:s', strtotime($log->created_at)); ?></td>
                                    <td>
                                        <a href="<?php echo esc_url($log->url); ?>" target="_blank" class="sip-url-link">
                                            <?php echo esc_html(wp_trim_words($log->url, 6, '...')); ?>
                                        </a>
                                    </td>
                                    <td><?php echo esc_html($log->api_key_name ?: 'N/A'); ?></td>
                                    <td><span class="sip-status sip-status-pending"><?php echo esc_html(ucfirst($log->action)); ?></span></td>
                                    <td>
                                        <span class="sip-status <?php echo $log->status === 'success' ? 'sip-status-success' : 'sip-status-error'; ?>">
                                            <?php echo esc_html(ucfirst($log->status)); ?>
                                        </span>
                                    </td>
                                    <td><?php echo esc_html($log->message); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="sip-no-data">No logs found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>