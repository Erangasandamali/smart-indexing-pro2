<?php
if (!defined('ABSPATH')) {
    exit;
}

// Handle form submission
if (isset($_POST['save_advanced_settings'])) {
    if (!wp_verify_nonce($_POST['sip_advanced_nonce'], 'sip_advanced_settings')) {
        wp_die('Security check failed');
    }
    
    $settings = get_option('sip_settings', array());
    
    // REST API settings
    $settings['enable_rest_api'] = isset($_POST['enable_rest_api']) ? 1 : 0;
    if (isset($_POST['regenerate_api_key']) && $_POST['regenerate_api_key']) {
        update_option('sip_rest_api_key', wp_generate_password(32, false));
    }
    
    // Multisite settings
    $settings['multisite_enabled'] = isset($_POST['multisite_enabled']) ? 1 : 0;
    
    // Notification settings
    $settings['email_notifications'] = isset($_POST['email_notifications']) ? 1 : 0;
    $settings['notification_email'] = sanitize_email($_POST['notification_email']);
    $settings['daily_reports'] = isset($_POST['daily_reports']) ? 1 : 0;
    
    // Slack settings
    $settings['slack_webhook'] = esc_url_raw($_POST['slack_webhook']);
    
    // Telegram settings
    $settings['telegram_bot_token'] = sanitize_text_field($_POST['telegram_bot_token']);
    $settings['telegram_chat_id'] = sanitize_text_field($_POST['telegram_chat_id']);
    
    // Cloudflare Worker settings
    $settings['cloudflare_worker_url'] = esc_url_raw($_POST['cloudflare_worker_url']);
    $settings['cloudflare_auth_token'] = sanitize_text_field($_POST['cloudflare_auth_token']);
    $settings['enable_cloudflare_worker'] = isset($_POST['enable_cloudflare_worker']) ? 1 : 0;
    
    update_option('sip_settings', $settings);
    echo '<div class="notice notice-success"><p>Advanced settings saved successfully!</p></div>';
}

$settings = get_option('sip_settings', array());
$rest_api_key = get_option('sip_rest_api_key', '');
if (empty($rest_api_key)) {
    $rest_api_key = wp_generate_password(32, false);
    update_option('sip_rest_api_key', $rest_api_key);
}
?>

<div class="wrap">
    <div class="sip-dashboard">
        <h1 class="sip-page-title">
            <span class="dashicons dashicons-admin-tools"></span>
            Advanced Features
        </h1>
        
        <form method="post" action="">
            <?php wp_nonce_field('sip_advanced_settings', 'sip_advanced_nonce'); ?>
            
            <!-- REST API Section -->
            <div class="sip-card">
                <div class="sip-card-header">
                    <h2>🚀 REST API</h2>
                    <p>Allow external tools to trigger indexing</p>
                </div>
                <div class="sip-card-content">
                    <table class="form-table">
                        <tr>
                            <th scope="row">Enable REST API</th>
                            <td>
                                <label class="sip-switch">
                                    <input type="checkbox" name="enable_rest_api" value="1" <?php checked(isset($settings['enable_rest_api']) ? $settings['enable_rest_api'] : 0, 1); ?>>
                                    <span class="sip-slider"></span>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">API Key</th>
                            <td>
                                <input type="text" value="<?php echo esc_attr($rest_api_key); ?>" readonly class="regular-text" style="background: #f1f1f1;">
                                <label>
                                    <input type="checkbox" name="regenerate_api_key" value="1"> Regenerate on save
                                </label>
                                <p class="description">
                                    <strong>Endpoints:</strong><br>
                                    POST <?php echo rest_url('sip/v1/submit-url'); ?><br>
                                    GET <?php echo rest_url('sip/v1/queue-status'); ?><br>
                                    GET <?php echo rest_url('sip/v1/indexing-status/{url}'); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <!-- Multisite Support Section -->
            <?php if (is_multisite()): ?>
            <div class="sip-card">
                <div class="sip-card-header">
                    <h2>🌐 Multisite Support</h2>
                    <p>Handle indexing per sub-site</p>
                </div>
                <div class="sip-card-content">
                    <table class="form-table">
                        <tr>
                            <th scope="row">Enable Multisite Features</th>
                            <td>
                                <label class="sip-switch">
                                    <input type="checkbox" name="multisite_enabled" value="1" <?php checked(isset($settings['multisite_enabled']) ? $settings['multisite_enabled'] : 0, 1); ?>>
                                    <span class="sip-slider"></span>
                                </label>
                                <p class="description">Enable per-site API key management and separate queue handling</p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Email Notifications Section -->
            <div class="sip-card">
                <div class="sip-card-header">
                    <h2>📧 Email Notifications</h2>
                    <p>Real-time notifications of failures or quota exhaustion</p>
                </div>
                <div class="sip-card-content">
                    <table class="form-table">
                        <tr>
                            <th scope="row">Enable Email Notifications</th>
                            <td>
                                <label class="sip-switch">
                                    <input type="checkbox" name="email_notifications" value="1" <?php checked(isset($settings['email_notifications']) ? $settings['email_notifications'] : 0, 1); ?>>
                                    <span class="sip-slider"></span>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Notification Email</th>
                            <td>
                                <input type="email" name="notification_email" value="<?php echo esc_attr(isset($settings['notification_email']) ? $settings['notification_email'] : get_option('admin_email')); ?>" class="regular-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Daily Reports</th>
                            <td>
                                <label class="sip-switch">
                                    <input type="checkbox" name="daily_reports" value="1" <?php checked(isset($settings['daily_reports']) ? $settings['daily_reports'] : 0, 1); ?>>
                                    <span class="sip-slider"></span>
                                </label>
                                <p class="description">Receive daily summary reports</p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <!-- Slack Notifications Section -->
            <div class="sip-card">
                <div class="sip-card-header">
                    <h2>💬 Slack Notifications</h2>
                    <p>Send alerts directly to your Slack channel</p>
                </div>
                <div class="sip-card-content">
                    <table class="form-table">
                        <tr>
                            <th scope="row">Slack Webhook URL</th>
                            <td>
                                <input type="url" name="slack_webhook" value="<?php echo esc_attr(isset($settings['slack_webhook']) ? $settings['slack_webhook'] : ''); ?>" class="regular-text" placeholder="https://hooks.slack.com/services/...">
                                <p class="description">Create a webhook in your Slack workspace to receive notifications</p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <!-- Telegram Notifications Section -->
            <div class="sip-card">
                <div class="sip-card-header">
                    <h2>📱 Telegram Notifications</h2>
                    <p>Send alerts to your Telegram chat</p>
                </div>
                <div class="sip-card-content">
                    <table class="form-table">
                        <tr>
                            <th scope="row">Bot Token</th>
                            <td>
                                <input type="text" name="telegram_bot_token" value="<?php echo esc_attr(isset($settings['telegram_bot_token']) ? $settings['telegram_bot_token'] : ''); ?>" class="regular-text" placeholder="123456789:ABCdefGHIjklMNOpqrsTUVwxyz">
                                <p class="description">Create a bot with @BotFather to get your token</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Chat ID</th>
                            <td>
                                <input type="text" name="telegram_chat_id" value="<?php echo esc_attr(isset($settings['telegram_chat_id']) ? $settings['telegram_chat_id'] : ''); ?>" class="regular-text" placeholder="-123456789">
                                <p class="description">Your chat ID or group chat ID (use @userinfobot to find it)</p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <!-- Cloudflare Worker Section -->
            <div class="sip-card">
                <div class="sip-card-header">
                    <h2>☁️ Cloudflare Worker Support</h2>
                    <p>Optional remote queue handling</p>
                </div>
                <div class="sip-card-content">
                    <table class="form-table">
                        <tr>
                            <th scope="row">Enable Cloudflare Worker</th>
                            <td>
                                <label class="sip-switch">
                                    <input type="checkbox" name="enable_cloudflare_worker" value="1" <?php checked(isset($settings['enable_cloudflare_worker']) ? $settings['enable_cloudflare_worker'] : 0, 1); ?>>
                                    <span class="sip-slider"></span>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Worker URL</th>
                            <td>
                                <input type="url" name="cloudflare_worker_url" value="<?php echo esc_attr(isset($settings['cloudflare_worker_url']) ? $settings['cloudflare_worker_url'] : ''); ?>" class="regular-text" placeholder="https://your-worker.your-subdomain.workers.dev">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Auth Token</th>
                            <td>
                                <input type="text" name="cloudflare_auth_token" value="<?php echo esc_attr(isset($settings['cloudflare_auth_token']) ? $settings['cloudflare_auth_token'] : ''); ?>" class="regular-text">
                                <p class="description">Authentication token for your Cloudflare Worker</p>
                            </td>
                        </tr>
                    </table>
                    
                    <div class="sip-worker-template" style="margin-top: 20px;">
                        <h4>Cloudflare Worker Template:</h4>
                        <textarea readonly style="width: 100%; height: 200px; font-family: monospace; font-size: 12px; background: #f9f9f9; border: 1px solid #ddd; padding: 10px;"><?php 
                        $cloudflare_worker = new SIP_Cloudflare_Worker();
                        echo esc_textarea($cloudflare_worker->get_worker_template());
                        ?></textarea>
                        <p class="description">Copy this template to create your Cloudflare Worker</p>
                    </div>
                </div>
            </div>
            
            <p class="submit">
                <input type="submit" name="save_advanced_settings" class="sip-btn sip-btn-primary" value="Save Advanced Settings">
            </p>
        </form>
    </div>
</div>